# ==========================================
# main_tool.py  -  engine for Mr. Chung's Pokemon Math Battle (Precalculus 11)
#   Scaling, fonts, math text, animations, Pokemon, moves, buttons, messages, music.
#   No game content lives here: main.py supplies the topics, questions, graphs and
#   battles, and pokedex.py says which Pokemon uses which sprite, where it stands
#   and how big it is.
#     - render_rich: "x^12" and "x^2" are drawn with a small raised number (section 2)
#     - every Pokemon's spot, size and animation settings come from pokedex.py (section 4)
#     - Button: a long answer wraps onto two lines (section 5)
# ==========================================
import pygame
import random
import os
import re
import sys

import pokedex


# ==========================================
# 1. PATHS & SCALING
# ==========================================
def resource_path(relative_path):
    base_path = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base_path, relative_path)


BASE_W, BASE_H = 1080, 950
curr_w, curr_h = 1080, 950


def rx(x): return int((x / BASE_W) * curr_w)
def ry(y): return int((y / BASE_H) * curr_h)
def rs(size): return max(2, int(size * min(curr_w / BASE_W, curr_h / BASE_H)))


# ==========================================
# 2. FONTS & TEXT
# ==========================================
FONT_PATH = "caslon.ttf"
_font_cache = {}


def get_font(size):
    scaled = rs(size)
    if scaled not in _font_cache:
        _font_cache[scaled] = pygame.font.Font(resource_path(FONT_PATH), scaled)
    return _font_cache[scaled]


# ---------- Math text: x^2, <=, infinity ... with safe fallbacks ----------
# "x^2" is always drawn as a small raised 2, so it works in any font.
# If caslon.ttf is missing one of the math symbols below, a plain-text
# version is used instead (e.g. "<=" for the one-character version), so nothing shows as a box.
_FALLBACK = {
    "\u2264": "<=", "\u2265": ">=", "\u221e": "inf", "\u2212": "-",
    "\u222a": "U", "\u211d": "R", "\u00b1": "+/-", "\u2208": "in",
}
_glyph_ok = {}


def _tobytes(surf):
    fn = getattr(pygame.image, "tobytes", None) or pygame.image.tostring
    return fn(surf, "RGB")


def _font_has(ch):
    """True if caslon.ttf really draws ch (not the 'missing character' box)."""
    if ch not in _glyph_ok:
        ok = False
        try:
            f = pygame.font.Font(resource_path(FONT_PATH), 40)
            m = f.metrics(ch)
            if m and m[0] is not None:
                ok = True
                s = _tobytes(f.render(ch, True, (0, 0, 0), (255, 255, 255)))
                for missing in ("\uffff", "\ufffe"):
                    try:
                        if s == _tobytes(f.render(missing, True, (0, 0, 0), (255, 255, 255))):
                            ok = False
                    except Exception:
                        pass
        except Exception:
            ok = False
        _glyph_ok[ch] = ok
    return _glyph_ok[ch]


def clean_text(t):
    for ch, alt in _FALLBACK.items():
        if ch in t and not _font_has(ch):
            t = t.replace(ch, alt)
    return t


_rich_cache = {}


_SUP = re.compile(r"\^(\d+)|\u00b2")


def render_rich(text, size, color):
    """Text surface with every '\u00b2' and every '^' + digits ('x^12') drawn as a small raised number (cached).
    (Plain ASCII in the question files: no special characters needed for exponents.)"""
    key = (text, size, tuple(color))
    surf = _rich_cache.get(key)
    if surf is None:
        if len(_rich_cache) > 3000:
            _rich_cache.clear()
        t = clean_text(text)
        font = get_font(size)
        small = get_font(max(8, int(size * 0.62)))
        pieces = []
        pos = 0
        for m in _SUP.finditer(t):
            if m.start() > pos:
                pieces.append((font.render(t[pos:m.start()], True, color), False))
            pieces.append((small.render(m.group(1) or "2", True, color), True))
            pos = m.end()
        if pos < len(t) or not pieces:
            pieces.append((font.render(t[pos:], True, color), False))
        h = font.get_height()
        w = sum(p.get_width() for p, _ in pieces)
        surf = pygame.Surface((max(1, w), h), pygame.SRCALPHA)
        x = 0
        for p, sup in pieces:
            surf.blit(p, (x, int(font.get_ascent() * 0.08) if sup else 0))
            x += p.get_width()
        _rich_cache[key] = surf
    return surf


def text_w(text, size):
    return render_rich(text, size, (0, 0, 0)).get_width()


def fit_size(text, size, max_w, min_size=10):
    """Largest font size (<= size) that keeps text within max_w base pixels."""
    while size > min_size and text_w(text, size) > rx(max_w):
        size -= 1
    return size


def draw_center(screen, text, size, color, base_y, base_x=BASE_W / 2):
    s = render_rich(text, size, color)
    screen.blit(s, s.get_rect(center=(rx(base_x), ry(base_y))))


def draw_lines(screen, text, color, base_x, base_y_center, max_w, size=26):
    """Draws text (one line, or two lines split at '\\n'), shrinking it to fit max_w."""
    lines = text.split("\n")
    if len(lines) > 1:
        size = min(size, 21)
    size = min(fit_size(l, size, max_w) for l in lines)
    surfs = [render_rich(l, size, color) for l in lines]
    lh = surfs[0].get_height()
    top = ry(base_y_center) - lh * len(lines) // 2
    for i, s in enumerate(surfs):
        screen.blit(s, (rx(base_x), top + i * lh))


# ==========================================
# 3. ANIMATION FRAMES
# ==========================================
def load_frames(path_template, target_size=None, scale_factor=1.0, max_frames=60):
    """Load 'name (1).gif', 'name (2).gif', ... until a file is missing."""
    frames = []
    for i in range(1, max_frames + 1):
        try:
            img = pygame.image.load(path_template.format(i=i))
        except (pygame.error, FileNotFoundError, OSError):
            break
        if target_size:
            img = pygame.transform.scale(img, target_size)
        elif scale_factor != 1.0:
            img = pygame.transform.scale(img, (int(img.get_width() * scale_factor),
                                               int(img.get_height() * scale_factor)))
        frames.append(img)
    return frames


class Later:
    """Frames that are only loaded (and scaled) the first time they are needed."""
    def __init__(self, make):
        self.make, self.frames = make, None

    def get(self):
        if self.frames is None:
            self.frames = self.make()
        return self.frames


class Animation:
    def __init__(self, original_frames, speed=4, loop=False):
        self._source = original_frames           # a list of frames, or Later (loaded on first play)
        self.frames = None                       # the frames at the current window size
        self.speed = speed
        self.loop = loop
        self.timer = 0
        self.is_playing = loop
        self.last_size = (BASE_W, BASE_H)

    @property
    def original_frames(self):
        if isinstance(self._source, Later):
            self._source = self._source.get()
        return self._source

    def play(self):
        self.timer = 0
        self.is_playing = True

    def draw(self, surface, base_x, base_y):
        if not self.is_playing or not self.original_frames:
            return
        if self.frames is None or self.last_size != (curr_w, curr_h):   # rescale only if the window changed
            same = (curr_w, curr_h) == (BASE_W, BASE_H)
            self.frames = self.original_frames if same else [
                pygame.transform.scale(img, (rx(img.get_width()), ry(img.get_height()))) for img in self.original_frames]
            self.last_size = (curr_w, curr_h)

        frame_idx = self.timer // self.speed
        if frame_idx >= len(self.frames):
            if not self.loop:
                self.is_playing = False
                return
            self.timer, frame_idx = 0, 0
        surface.blit(self.frames[frame_idx], (rx(base_x), ry(base_y)))
        self.timer += 1


def load_vfx():
    """The attack/heal animations.  Each one is loaded the first time it plays (not at startup)."""
    spec = {
        "hit":         ("hit",           (400, 400)),
        "heal":        ("heal",          (400, 400)),
        "firepunch":   ("firepunch",     (500, 500)),
        "thunderbolt": ("lightning",     (200, 500)),
        "hydropump":   ("water",         (600, 600)),
        "thunder":     ("green_thunder", (500, 600)),
        "leaftornado": ("leaf_tornado",  (400, 600)),
    }
    return {key: Later(lambda f=fname, s=size: load_frames(resource_path(f"vfx/{f} ({{i}}).gif"), target_size=s))
            for key, (fname, size) in spec.items()}


# ==========================================
# 4. POKEMON SPRITES AND PLACES ON SCREEN
# ==========================================
# Which Pokemon uses which folder, and its moves: pokedex.py.
# Sprite files: pokemonN/pokemonN_front (1).gif ...  and  pokemonN/pokemonN_back (1).gif ...
# (pokemonN/pokemon_N (1).gif also works.)
#
# A "spot" is a place on screen for one Pokemon.  ALL spots, sizes and animation settings live in
# pokedex.py (section 2): pass  spot=pokedex.spot("team_foe1", name)  and  fx=pokedex.fx("team_foe1"),
# so each Pokemon's "scale", "shift" and per-mode nudges are already applied.
SPOTS = pokedex.SPOTS

_raw_cache, _fit_cache, _vfx_cache = {}, {}, {}


def _raw_frames(folder, view):
    """Frames for one view ('front' or 'back'); falls back to the other view, then pokemon_N."""
    key = (folder, view)
    if key not in _raw_cache:
        frames = []
        if folder is not None:
            other = "back" if view == "front" else "front"
            for name in (f"pokemon{folder}_{view}", f"pokemon{folder}_{other}", f"pokemon_{folder}"):
                frames = load_frames(resource_path(f"pokemon{folder}/{name} ({{i}}).gif"))
                if frames:
                    break
        _raw_cache[key] = frames
    return _raw_cache[key]


def fitted_frames(folder, view, size):
    """Frames scaled so the visible Pokemon fits size = (height, width), and its visible box."""
    key = (folder, view, size)
    if key not in _fit_cache:
        raw = _raw_frames(folder, view)
        if not raw:
            _fit_cache[key] = ([], pygame.Rect(0, 0, size[1], size[0]))
        else:
            bb = raw[0].get_bounding_rect()            # the visible part (skips empty margins)
            if bb.w < 4 or bb.h < 4:
                bb = raw[0].get_rect()
            k = min(size[0] / bb.h, size[1] / bb.w)
            frames = [pygame.transform.scale(f, (max(1, int(f.get_width() * k)), max(1, int(f.get_height() * k))))
                      for f in raw]
            _fit_cache[key] = (frames, pygame.Rect(int(bb.x * k), int(bb.y * k), int(bb.w * k), int(bb.h * k)))
    return _fit_cache[key]


def zoomed_frames(folder, view, k):
    """Frames at k x their real size, and the visible part of the Pokemon (for placing it)."""
    key = (folder, view, round(k, 4))
    if key not in _fit_cache:
        raw = _raw_frames(folder, view)
        if not raw:
            _fit_cache[key] = ([], pygame.Rect(0, 0, 200, 200))
        else:
            bb = raw[0].get_bounding_rect()            # the visible part (skips empty margins)
            if bb.w < 4 or bb.h < 4:
                bb = raw[0].get_rect()
            frames = [pygame.transform.scale(f, (max(1, int(f.get_width() * k)), max(1, int(f.get_height() * k))))
                      for f in raw]
            _fit_cache[key] = (frames, pygame.Rect(int(bb.x * k), int(bb.y * k), int(bb.w * k), int(bb.h * k)))
    return _fit_cache[key]


def _frames_of(v):
    return v.get() if isinstance(v, Later) else v


def scaled_vfx(vfx, scale):
    """The animations at another size (Team Battle, Class Raid), each one also made only when first played."""
    if scale == 1:
        return vfx
    if scale not in _vfx_cache:
        _vfx_cache[scale] = {
            k: Later(lambda v=v: [pygame.transform.scale(f, (int(f.get_width() * scale), int(f.get_height() * scale)))
                                  for f in _frames_of(v)])
            for k, v in vfx.items()}
    return _vfx_cache[scale]


class Pokemon:
    FX_SPEED = {"hit": 3, "heal": 3, "thunderbolt": 3, "firepunch": 4,
                "hydropump": 4, "thunder": 3, "leaftornado": 3}
    FX_FROM_SKY = {"thunderbolt", "thunder", "leaftornado"}      # these come down onto the Pokemon

    # Effect positions in the original single-player layout (from the sprite's top-left x, y)
    LAYOUT_FX = {"hit": (0, 25), "heal": (0, 0), "firepunch": (-20, -150),
                 "hydropump": (-50, -50), "thunder": (-50, -220), "leaftornado": (-50, -220)}

    def __init__(self, name, hp, max_hp, attack, defense, vfx_frames, view="front", spot=None, vfx_scale=1,
                 layout=None, fx=None):
        """spot   = place on screen (pokedex.spot(...): the Pokemon's own nudges already applied).
           layout = the original hand-tuned single-player numbers from pokedex.py ("single").
           fx     = animation settings (pokedex.fx(...)): scale, shift, by_effect."""
        entry = pokedex.info(name)
        spot = spot or pokedex.spot("single_enemy", name)
        fx = fx or {"scale": vfx_scale}
        self.fx_shift = fx.get("shift", (0, 0))
        self.fx_by_effect = fx.get("by_effect", {})
        self.name, self.hp, self.max_hp = name, hp, max_hp
        self.attack, self.defense = attack, defense
        self.moves = []
        self.fainted = False
        self.label, self.label_color = name, (255, 255, 255)     # text in the HP box
        self.layout = layout
        self.ax, self.ay = spot["anchor"]
        self.bx, self.by = spot["box"]
        self.panel = spot.get("panel", False)
        if layout:                                                # original single-player spot
            self.bx, self.by, self.img_x, self.img_y, tdx, tdy, k = layout
            self.tb_shift = (tdx, tdy)
            frames, box = zoomed_frames(entry.get("folder"), view, k)
            self.ax, self.ay = self.img_x + box.x + box.w / 2, self.img_y + box.y + box.h
            self.cx, self.cy = self.ax, self.ay - box.h / 2
        elif "scale" in spot:                                       # real size x zoom (natural sizes)
            frames, box = zoomed_frames(entry.get("folder"), view, spot["scale"])
        else:                                                     # fitted into a box (Class Raid's Mewtwo)
            frames, box = fitted_frames(entry.get("folder"), view, tuple(spot["size"]))
        if not layout:
            self.img_x = self.ax - (box.x + box.w / 2)
            self.img_y = self.ay - (box.y + box.h)
            self.cx, self.cy = self.ax, self.ay - box.h / 2       # middle of the visible sprite
        self.idle = Animation(frames, speed=4, loop=True)
        frames_fx = scaled_vfx(vfx_frames, fx.get("scale", 1))
        self.animations = {k: Animation(frames_fx.get(k, []), speed=sp) for k, sp in self.FX_SPEED.items()}
        folder = entry.get("folder")
        try:
            self.faint_sound = pygame.mixer.Sound(resource_path(f"pokemon{folder}/pokemon{folder}_faint.ogg"))
            self.faint_sound.set_volume(0.4)
        except (pygame.error, FileNotFoundError, OSError, TypeError):
            self.faint_sound = None

    def play_faint_sound(self):
        """Faints: plays the sound once and stops drawing the sprite."""
        if not self.fainted:
            self.fainted = True
            if self.faint_sound:
                self.faint_sound.play()

    def revive(self):
        self.hp, self.fainted = self.max_hp, False

    def trigger_vfx(self, effect_data):
        effects = effect_data if isinstance(effect_data, (list, tuple)) else [effect_data]
        for effect in effects:
            if effect in self.animations:
                self.animations[effect].play()

    def draw(self, surface, active=False):
        if not self.fainted:
            self.idle.draw(surface, self.img_x, self.img_y)
        for key, anim in self.animations.items():
            if not anim.is_playing or not anim.original_frames:
                continue
            w, h = anim.original_frames[0].get_size()
            if self.layout:                                       # original fixed offsets
                dx, dy = self.tb_shift if key == "thunderbolt" else self.LAYOUT_FX.get(key, (0, 0))
                anim.draw(surface, self.img_x + dx, self.img_y + dy)
            else:                                                 # fx shift (+ this effect's own nudge)
                ex, ey = self.fx_by_effect.get(key, (0, 0))
                dx, dy = self.fx_shift[0] + ex, self.fx_shift[1] + ey
                if key in self.FX_FROM_SKY:                       # comes down onto the feet
                    anim.draw(surface, self.ax - w / 2 + dx, self.ay - h + dy)
                else:                                             # on the middle of the Pokemon
                    anim.draw(surface, self.cx - w / 2 + dx, self.cy - h / 2 + dy)
        self.draw_hp_box(surface, active)

    def box_rect(self):
        """The name/HP plate on screen (for clicking it)."""
        w = 270 if self.panel else 300
        return pygame.Rect(rx(self.bx - 12), ry(self.by - 8), rx(w + 24), ry(98))

    def draw_hp_box(self, surface, active=False):
        x, y = self.bx, self.by
        w = 270 if self.panel else 300
        grey = (170, 170, 170)
        if self.panel:
            r = pygame.Rect(rx(x - 12), ry(y - 8), rx(w + 24), ry(98))
            bg = pygame.Surface(r.size, pygame.SRCALPHA)
            bg.fill((0, 0, 0, 110))
            surface.blit(bg, r.topleft)
            if active:
                pygame.draw.rect(surface, (255, 220, 60), r, max(2, rs(4)))
        s = render_rich(self.label, fit_size(self.label, 26 if not self.panel else 24, w),
                        grey if self.fainted else self.label_color)
        surface.blit(s, (rx(x), ry(y)))
        ratio = max(0, self.hp / self.max_hp)
        bar_y, txt_y, txt_size = (y + 40, y + 60, 26) if self.layout else (y + 38, y + 56, 22 if not self.panel else 20)
        red, green = ((255, 0, 0), (0, 255, 0)) if self.layout else ((220, 0, 0), (0, 220, 0))
        pygame.draw.rect(surface, red, (rx(x), ry(bar_y), rx(w), ry(12)))
        pygame.draw.rect(surface, green, (rx(x), ry(bar_y), rx(w * ratio), ry(12)))
        hp_text = "Fainted" if self.fainted else f"HP: {int(self.hp)} / {int(self.max_hp)}"
        s = render_rich(hp_text, txt_size, grey if self.fainted else (255, 255, 255))
        surface.blit(s, (rx(x), ry(txt_y)))


# ==========================================
# 5. MESSAGES, MOVES, BUTTONS
# ==========================================
class MessageSystem:
    def __init__(self):
        self.queue, self.current = [], ""

    def draw(self, surface):
        draw_lines(surface, self.current, (255, 255, 255), 85, 768, 905)

    def add(self, text, target=None, hp_change=0, vfx=None, sound=None):
        self.queue.append({"text": text, "target": target, "hp_change": hp_change, "vfx": vfx, "sound": sound})

    def clear(self):
        self.current = ""

    def has_active_message(self):
        return bool(self.current) or bool(self.queue)

    def update(self):
        if self.current or not self.queue:
            return
        msg = self.queue.pop(0)
        self.current = msg["text"]
        t = msg["target"]
        if t is None:
            return
        t.hp += msg["hp_change"]
        if msg["hp_change"] < 0:
            if msg["vfx"]:   t.trigger_vfx(msg["vfx"])
            if msg["sound"]: msg["sound"].play()
        elif msg["hp_change"] > 0:
            t.trigger_vfx("heal")
        t.hp = max(0, min(t.hp, t.max_hp))


class Move:
    def __init__(self, name, power, miss_chance, crit_chance, category, vfx, sound):
        self.name, self.power = name, power
        self.miss_chance, self.crit_chance = miss_chance, crit_chance
        self.category, self.vfx, self.sound = category, vfx, sound

    def execute(self, attacker, defender, msg_sys, heal_sound_ref):
        msg_sys.add(f"{attacker.name} used {self.name}!")
        if self.category == "heal":
            msg_sys.add(f"{attacker.name} recovered HP!", target=attacker, hp_change=self.power)
            if heal_sound_ref: heal_sound_ref.play()
        elif self.category == "buff":
            attacker.attack *= self.power
            msg_sys.add(f"{attacker.name}'s Attack sharply rose!")
        else:
            damage = int(self.power * (attacker.attack / 100))
            if random.randint(1, 100) <= self.miss_chance:
                msg_sys.add(f"{attacker.name}'s Attack missed!")
            elif random.randint(1, 100) <= self.crit_chance:
                msg_sys.add(f"A critical hit! It dealt {int(damage * 1.5)} damage!",
                            target=defender, hp_change=-int(damage * 1.5), vfx=self.vfx, sound=self.sound)
            else:
                msg_sys.add(f"It dealt {damage} damage!", target=defender, hp_change=-damage,
                            vfx=self.vfx, sound=self.sound)


def make_moves(name, sounds):
    """A Pokemon's moves from pokedex.py, ready to use in battle."""
    out = []
    for move_name, power, miss, crit, effect in pokedex.moves(name):
        anims, sound = pokedex.EFFECTS.get(effect, pokedex.EFFECTS["hit"])
        out.append(Move(move_name, power, miss, crit, "damage", anims, sounds.get(sound)))
    return out


class Button:
    """Button that can show x^2, <= etc. and shrinks long answers to fit.
    A very long answer (like "The months until the total cost is $150") wraps onto two lines."""
    WRAP_BELOW = 17          # if one line would need a font smaller than this, try two lines

    def __init__(self, base_x, base_y, base_w, base_h, color=(150, 200, 200)):
        self.text = ""
        self.color = color
        self.text_color = (0, 0, 0)
        self.border_color = (0, 0, 0)       # the outline (a faint button can use a grey one)
        self.bx, self.by, self.bw, self.bh = base_x, base_y, base_w, base_h
        self._fit = {}       # (text, size) -> (font size, [lines])   so it is worked out once

    def rect(self):
        return pygame.Rect(rx(self.bx), ry(self.by), rx(self.bw), ry(self.bh))

    def _layout(self, size):
        key = (self.text, size)
        if key not in self._fit:
            if len(self._fit) > 200:
                self._fit.clear()
            room = self.bw - 14
            one = fit_size(self.text, size, room)
            best = (one, [self.text])
            words = self.text.split()
            if one < self.WRAP_BELOW and len(words) > 2:
                for k in range(1, len(words)):
                    a, b = " ".join(words[:k]), " ".join(words[k:])
                    sz = min(fit_size(a, min(size, 22), room), fit_size(b, min(size, 22), room))
                    if sz > best[0]:
                        best = (sz, [a, b])
            self._fit[key] = best
        return self._fit[key]

    def draw(self, surface, size=24):
        rect = self.rect()
        pygame.draw.rect(surface, self.color, rect)
        pygame.draw.rect(surface, self.border_color, rect, max(1, rs(2)))
        sz, lines = self._layout(size)
        if len(lines) == 1:
            s = render_rich(lines[0], sz, self.text_color)
            surface.blit(s, s.get_rect(center=rect.center))
            return
        for line, dy in zip(lines, (-0.25, 0.25)):
            s = render_rich(line, sz, self.text_color)
            surface.blit(s, s.get_rect(center=(rect.centerx, rect.centery + int(dy * rect.h))))

    def clicked(self, mousepos):
        return self.rect().collidepoint(mousepos)


# ==========================================
# 6. MUSIC
# ==========================================
MUSIC_END_EVENT = pygame.USEREVENT + 1


def play_random_track(music_pool):
    """Plays a random track from the pool (music5.ogg ...). If a file is missing or won't load,
    another track from the same pool is tried. If none load, the music stops, so the last
    battle's music never keeps playing in the wrong battle."""
    if not music_pool:
        return
    for n in random.sample(list(music_pool), len(music_pool)):
        try:
            pygame.mixer.music.load(resource_path(f"music{n}.ogg"))      # pygbag needs OGG
            pygame.mixer.music.set_volume(0.15)
            pygame.mixer.music.play(0)
            return
        except (pygame.error, FileNotFoundError, OSError):
            continue
    try:
        pygame.mixer.music.stop()
    except pygame.error:
        pass
