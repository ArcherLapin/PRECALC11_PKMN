# ==========================================
# rational.py  -  Precalculus 11, Unit 5 Rational Expressions: every question.  (No pygame here.)
#   main.py turns each (question, right answer, wrong answers) into a battle question.
#
#   5.1 Simplifying               NPVs, monomials, factor + cancel, opposites, x^3 GCFs, "nothing cancels"
#   5.2 Multiplying + Dividing    monomials (2 variables), factor + multiply, dividing, opposites, NPVs of a division
#   5.3 Adding + Subtracting I    monomial denominators (x, or two variables), binomial tops, a whole term, 3 terms
#   5.4 Adding + Subtracting II   the 6 DeltaMath Level 2 types (two binomials, factor first, opposites,
#                                 two trinomials, binomial + x, binomial + no denominator)
#   5.5 Solving                   monomial (linear and quadratic), cross-multiply, extraneous roots,
#                                 a whole x term, LCM with a number, no solution
#
# Every question is built from random numbers (no question bank), so it is different every time.
# Every wrong answer is a real mistake (the booklet's WATCH OUTs: cancelling terms, forgetting the -1
# of opposites, NPVs from the simplified answer only, forgetting to flip, adding straight across,
# not distributing the minus, forgetting to multiply a whole term by the LCD, not rejecting a root...).
# Every wrong answer is checked to really be wrong: it is worked out at a few x-values and must
# differ from the right answer (so a "not fully simplified" but equal answer is never marked wrong).
#
# Fractions are written "{top|bottom}" and drawn stacked (main_tool.render_rich).
# Answers match the booklet: factored form for 5.1-5.2, an expanded top over a factored LCD for
# 5.3-5.4, NPVs like "x ≠ ±3, 4", solutions like "x = −4  (3 rejected)".
# ==========================================
import math
import random
from fractions import Fraction as F

MINUS = "−"
NE = "≠"
PM = "±"
DOT = "·"
DIV = "÷"


# ==========================================
# 1. NUMBERS AND POLYNOMIALS
# ==========================================
def fmt(v):
    """3, -2 and stacked fractions like {1|2} (with a real minus sign)."""
    v = F(v)
    s = str(abs(v.numerator)) if v.denominator == 1 else "{%d|%d}" % (abs(v.numerator), v.denominator)
    return (MINUS if v < 0 else "") + s


def nz(lo, hi, avoid=()):
    return random.choice([i for i in range(lo, hi + 1) if i != 0 and i not in avoid])


def _sup(e):
    return "" if e == 1 else "²" if e == 2 else f"^{e}"


class Poly:
    """A polynomial in the variables vs (usually just x): {exponents: coefficient}."""
    def __init__(self, terms=None, vs=("x",)):
        self.vs = tuple(vs)
        self.t = {}
        for k, v in (terms or {}).items():
            v = F(v)
            if v != 0:
                self.t[tuple(k)] = v

    @classmethod
    def const(cls, c, vs=("x",)):
        return cls({(0,) * len(vs): c}, vs)

    def _c(self, o):
        return o if isinstance(o, Poly) else Poly.const(o, self.vs)

    def __add__(self, o):
        o = self._c(o)
        r = dict(self.t)
        for k, v in o.t.items():
            r[k] = r.get(k, 0) + v
        return Poly(r, self.vs)

    __radd__ = __add__

    def __neg__(self):
        return Poly({k: -v for k, v in self.t.items()}, self.vs)

    def __sub__(self, o):
        return self + (-self._c(o))

    def __rsub__(self, o):
        return self._c(o) - self

    def __mul__(self, o):
        o = self._c(o)
        r = {}
        for k1, v1 in self.t.items():
            for k2, v2 in o.t.items():
                k = tuple(a + b for a, b in zip(k1, k2))
                r[k] = r.get(k, 0) + v1 * v2
        return Poly(r, self.vs)

    __rmul__ = __mul__

    def __pow__(self, n):
        r = Poly.const(1, self.vs)
        for _ in range(n):
            r = r * self
        return r

    def __eq__(self, o):
        return isinstance(o, Poly) and self.t == o.t

    def __hash__(self):
        return hash(tuple(sorted(self.t.items())))

    def is_zero(self):
        return not self.t

    def deg(self):
        return max((sum(k) for k in self.t), default=-1)

    def ev(self, pt):
        pt = pt if isinstance(pt, tuple) else (pt,)
        total = F(0)
        for k, v in self.t.items():
            term = v
            for x, e in zip(pt, k):
                term *= F(x) ** e
            total += term
        return total

    def coef(self, e):                    # one variable only
        return self.t.get((e,), F(0))

    def lead(self):
        k = self._order()[0]
        return Poly({k: self.t[k]}, self.vs)

    def content(self):
        """gcd of the (whole-number) coefficients."""
        g = 0
        for v in self.t.values():
            if v.denominator != 1:
                return 1
            g = math.gcd(g, abs(v.numerator))
        return g or 1

    def _order(self):
        return sorted(self.t, key=lambda k: (-sum(k), [-e for e in k]))

    def text(self, ascending=False):
        if not self.t:
            return "0"
        keys = self._order()
        if ascending:
            keys = keys[::-1]
        out = ""
        for k in keys:
            c = self.t[k]
            mono = "".join(v + _sup(e) for v, e in zip(self.vs, k) if e)
            body = (fmt(abs(c)) if (abs(c) != 1 or not mono) else "") + mono
            if not out:
                out = (MINUS if c < 0 else "") + body
            else:
                out += (f" {MINUS} " if c < 0 else " + ") + body
        return out

    def show(self):
        """How a problem writes it: 4 - x^2 and 2 - x (not -x^2 + 4)."""
        keys = self._order()
        if len(keys) > 1 and self.t[keys[0]] < 0 and self.t[keys[-1]] > 0:
            return self.text(ascending=True)
        return self.text()


X = Poly({(1,): 1})


def lin(a, b):
    """ax + b."""
    return Poly({(1,): a, (0,): b})


def P(*cs):
    """P(1, -3, -10) = x^2 - 3x - 10."""
    n = len(cs) - 1
    return Poly({(n - i,): c for i, c in enumerate(cs)})


def divide_lin(p, a, b):
    """p / (ax + b) if it divides exactly (one variable), else None."""
    if p.is_zero():
        return p
    if p.ev(F(-b, a)) != 0:
        return None
    n = p.deg()
    cs = [p.coef(e) for e in range(n, -1, -1)]       # highest first
    out, carry = [], F(0)
    r = F(-b, a)
    for c in cs:
        carry = carry * r + c
        out.append(carry)
    q = out[:-1]                                     # quotient of p / (x - r)
    return Poly({(n - 1 - i,): c / a for i, c in enumerate(q)})


def rational_roots(p):
    """Roots of a 1-variable polynomial of degree 1 or 2 if they are all rational, else None.
    (A repeated root is listed once.)"""
    d = p.deg()
    if d == 1:
        return [-p.coef(0) / p.coef(1)]
    if d != 2:
        return None
    a, b, c = p.coef(2), p.coef(1), p.coef(0)
    disc = b * b - 4 * a * c
    if disc < 0:
        return None
    n, m = disc.numerator, disc.denominator
    rn, rm = math.isqrt(n), math.isqrt(m)
    if rn * rn != n or rm * rm != m:
        return None
    s = F(rn, rm)
    return sorted({(-b - s) / (2 * a), (-b + s) / (2 * a)})


# ==========================================
# 2. FACTORED FORM:  c * x^k * (x + 3)(2x - 1)^2 ...
# ==========================================
def ltext(a, b):
    return lin(a, b).text()


class Fac:
    """A number times linear factors (ax + b), each with a power.  Factors are stored with a > 0
    and no common number (the number goes into c), so (2 - x) is stored as -1 * (x - 2)."""
    def __init__(self, c=1, factors=()):
        self.c = F(c)
        self.f = {}
        for item in factors:
            if isinstance(item[0], tuple):
                self.add(item[0], item[1])
            else:
                self.add(item)

    def add(self, ab, k=1):
        a, b = ab
        g = math.gcd(abs(a), abs(b)) or 1
        a, b = a // g, b // g
        self.c *= F(g) ** k
        if a < 0:
            a, b = -a, -b
            self.c *= F(-1) ** k
        self.f[(a, b)] = self.f.get((a, b), 0) + k
        if self.f[(a, b)] == 0:
            del self.f[(a, b)]
        return self

    def copy(self):
        n = Fac(self.c)
        n.f = dict(self.f)
        return n

    def times(self, other):
        n = self.copy()
        n.c *= other.c
        for ab, k in other.f.items():
            n.add(ab, k)
        return n

    def poly(self):
        p = Poly.const(self.c)
        for (a, b), k in self.f.items():
            p = p * lin(a, b) ** k
        return p

    def roots(self):
        return {F(-b, a) for (a, b) in self.f}

    def body(self, c):
        """The text with the number c (a whole number, no sign) in front."""
        xs = self.f.get((1, 0), 0)
        others = [(ab, k) for ab, k in self.f.items() if ab != (1, 0)]
        coef = "" if c == 1 and (xs or others) else str(c)
        xpart = "x" + _sup(xs) if xs else ""
        if not others:
            return coef + xpart
        if len(others) == 1 and others[0][1] == 1 and not coef and not xpart:
            return ltext(*others[0][0])
        return coef + xpart + "".join(f"({ltext(*ab)})" + _sup(k) for ab, k in others)

    def single_binomial(self):
        return len(self.f) == 1 and list(self.f.values())[0] == 1 and (1, 0) not in self.f


def cancel(n, d):
    """n / d with common factors cancelled (n, d: Fac).  Returns new (n, d)."""
    n, d = n.copy(), d.copy()
    for ab in list(n.f):
        if ab in d.f:
            k = min(n.f[ab], d.f[ab])
            n.add(ab, -k)
            d.add(ab, -k)
    return n, d


def frac_text(n, d):
    """n / d (Fac) as text: the sign in front, like  -{x + 3|x - 3}  or  -(x + 3)  or  {2x(x + 2)|x + 3}."""
    c = n.c / d.c
    neg, c = c < 0, abs(c)
    top, bot = n.body(c.numerator), d.body(c.denominator)
    if not d.f and c.denominator == 1:
        s = f"({top})" if neg and n.single_binomial() and c.numerator == 1 else top
    else:
        s = "{%s|%s}" % (top, bot)
    return (MINUS if neg else "") + s


def over(top, bot):
    """{top|bot}, or just top when bot is 1."""
    return top if bot in ("1", "") else "{%s|%s}" % (top, bot)


def poly_over_fac(p, d):
    """An expanded top over a factored bottom, like {x^2 - 15|x(x - 3)} (the sign in front)."""
    c = 1 / d.c
    if p.is_zero():
        return "0"
    lead_c = p.t[p._order()[0]]
    neg = (lead_c * c) < 0
    if neg:
        p, c = -p, -c
    c = abs(c)
    top = p * c.numerator
    if not d.f and c.denominator == 1:
        s = top.text()
        if neg and len(top.t) > 1:
            s = f"({s})"
    else:
        s = "{%s|%s}" % (top.text(), d.body(c.denominator))
    return (MINUS if neg else "") + s


# ==========================================
# 3. CHECKING THAT WRONG ANSWERS ARE REALLY WRONG
# ==========================================
PTS1 = [F(7, 3), F(-13, 5), F(11, 7), F(-5, 9), F(17, 4)]
PTS2 = [(F(7, 3), F(-5, 4)), (F(-13, 5), F(9, 7)), (F(11, 7), F(3, 11)), (F(-5, 9), F(-8, 3))]


def sig(num, den, pts=None):
    """The value of num/den at a few odd points: equal signatures = the same expression."""
    pts = pts or (PTS1 if len(num.vs) == 1 else PTS2)
    out = []
    for p in pts:
        d = den.ev(p)
        out.append(None if d == 0 else num.ev(p) / d)
    return tuple(out)


def sigf(n, d):
    return sig(n.poly(), d.poly())


def opt_f(n, d):
    """(text, key) for a factored answer."""
    n, d = cancel(n, d)
    return frac_text(n, d), sigf(n, d)


def pack(text, correct, traps):
    """(question, right answer, wrong answers): wrong answers whose value equals the right one
    (or another wrong one) are dropped.  None if fewer than 4 are left."""
    if correct is None:
        return None
    ct, ck = correct
    keys, out = {ck}, []
    for t in traps:
        if t is None:
            continue
        tt, tk = t
        if tk in keys or tt == ct or tt in out:
            continue
        keys.add(tk)
        out.append(tt)
    if len(out) < 4:
        return None
    return text, ct, out


# ==========================================
# 4. NPVs AND SOLUTIONS AS TEXT
# ==========================================
def npv_list(vals):
    vals = sorted(set(F(v) for v in vals), key=lambda v: (abs(v), v))
    out, used = [], set()
    for v in vals:
        if v in used:
            continue
        if v != 0 and -v in vals:
            out.append(PM + fmt(abs(v)))
            used |= {v, -v}
        else:
            out.append(fmt(v))
            used.add(v)
    return ", ".join(out)


def npv_text(vals):
    return f"x {NE} {npv_list(vals)}" if vals else "No NPVs"


def npv_opt(vals):
    vals = frozenset(F(v) for v in vals)
    return npv_text(vals), ("npv", vals)


def sol_text(sols, rej=()):
    sols = sorted(set(sols))
    rej = sorted(set(rej))
    r = f"  ({', '.join(fmt(v) for v in rej)} rejected)" if rej else ""
    if not sols:
        return "No solution" + r
    return "x = " + ", ".join(fmt(v) for v in sols) + r


def sol_opt(sols, rej=()):
    return sol_text(sols, rej), ("sol", frozenset(sols), frozenset(rej))


def wrong_pairs(r, s):
    """Factor pairs that MULTIPLY to the right number but don't ADD to it (zeros m, k)."""
    prod, tot = r * s, r + s
    if prod == 0:
        return []
    n, out = abs(prod), []
    for d in range(1, n + 1):
        if n % d:
            continue
        for m in (d, -d):
            k = prod // m
            if m < k and m + k not in (tot, -tot):
                out.append((m, k))
    random.shuffle(out)
    out.sort(key=lambda mk: abs(abs(mk[1] - mk[0]) - abs(s - r)))
    return out


# ==========================================
# 5.  5.1 SIMPLIFYING
# ==========================================
def _num_expr():
    """A numerator for an NPV question, and its zero (or None)."""
    k = random.random()
    if k < 0.45:
        b = nz(-9, 9)
        return lin(1, b), [F(-b)]
    if k < 0.7:
        c = random.randint(2, 9)
        return Poly({(1,): c}), [F(0)]
    if k < 0.85:
        return Poly.const(random.randint(1, 9)), []
    r = nz(-6, 6)
    return lin(1, -r) * lin(1, nz(-6, 6, avoid=(r,))), []


def q51_npv():
    """DeltaMath Undefined Rationals: the NPVs of one rational expression."""
    num, nzeros = _num_expr()
    kind = random.choices(["lin", "tri", "ds", "gcf", "sdrf", "none"], weights=[3, 6, 3, 3, 2, 2])[0]
    traps = []
    if kind == "lin":
        a, b = random.choice([1, 1, 2, 3, 4, 5]), nz(-9, 9)
        den = lin(a, b)
        right = {F(-b, a)}
        traps += [npv_opt({F(b, a)}), npv_opt({F(-b)}) if a != 1 else npv_opt({F(b)}),
                  npv_opt({F(-a, b)}) if F(-a, b) != F(-b, a) else None, npv_opt({F(a, b)})]
    elif kind == "tri":
        r, s = random.sample([i for i in range(-9, 10) if i], 2)
        den = lin(1, -r) * lin(1, -s)
        right = {F(r), F(s)}
        traps += [npv_opt({-r, -s}), npv_opt({r, -s}), npv_opt({-r, s})]
        traps += [npv_opt({-m, -k}) for m, k in wrong_pairs(r, s)[:2]]
        traps += [npv_opt({r * s}), npv_opt({r})]
    elif kind == "ds":
        k = random.randint(1, 10)
        den = P(1, 0, -k * k)
        right = {F(k), F(-k)}
        traps += [npv_opt({k}), npv_opt({k * k, -k * k}) if k > 1 else npv_opt({0}), npv_opt(set()),
                  npv_opt({-k})]
    elif kind == "gcf":
        k = nz(-9, 9)
        p = random.choice([1, 1, 2])
        den = Poly({(p + 1,): 1, (p,): k})            # x^2 + kx  or  x^3 + kx^2
        right = {F(0), F(-k)}
        traps += [npv_opt({-k}), npv_opt({k}), npv_opt({0, k}), npv_opt({0})]
    elif kind == "sdrf":                              # (Ax + B)(x + D): SDRF
        A = random.choice([2, 2, 3, 3, 4, 5])
        B, D = nz(-9, 9), nz(-9, 9)
        if math.gcd(A, abs(B)) != 1 or abs(A * D + B) > 30:
            return None
        den = lin(A, B) * lin(1, D)
        right = {F(-B, A), F(-D)}
        traps += [npv_opt({F(B, A), F(D)}), npv_opt({-A * D, -B}),        # the helper's zeros (forgot to divide)
                  npv_opt({F(-B), F(-D)}), npv_opt({F(-A, B), F(-D)}), npv_opt({F(-D)})]
    else:                                             # x^2 + k^2 never equals 0
        k = random.randint(1, 9)
        den = P(1, 0, k * k)
        right = set()
        traps += [npv_opt({k, -k}), npv_opt({k}), npv_opt({k * k, -k * k}), npv_opt({-k})]
    if nzeros:
        traps.append(npv_opt(right | set(nzeros)))        # used the numerator too
        traps.append(npv_opt(set(nzeros)))
    if right:
        traps.append(npv_opt(set()))
    ex = "{%s|%s}" % (num.show(), den.show())
    text = random.choice(["Find the NPVs:  {}", "State the NPVs:  {}", "{}.  Which x-values are not allowed?"]).format(ex)
    return pack(text, npv_opt(right), traps)


VAR_PAIRS = [("m", "n"), ("a", "b"), ("x", "y"), ("p", "q")]


def mono_text(c, exps, vs, sign=True):
    """A monomial like -18m^4n^2 (c a whole number)."""
    body = "".join(v + _sup(e) for v, e in zip(vs, exps) if e)
    s = (str(abs(c)) if abs(c) != 1 or not body else "") + body
    return (MINUS if c < 0 and sign else "") + s


def monofrac(c, exps, vs):
    """(text, key) for c * a^e1 * b^e2 with exponents that can be negative (they go underneath)."""
    c = F(c)
    neg = c < 0
    c = abs(c)
    top = [e if e > 0 else 0 for e in exps]
    bot = [-e if e < 0 else 0 for e in exps]
    t = mono_text(c.numerator, top, vs)
    b = mono_text(c.denominator, bot, vs) if (c.denominator != 1 or any(bot)) else ""
    s = over(t, b)
    return (MINUS if neg else "") + s, ("mono", F(c) * (-1 if neg else 1), tuple(exps))


def q51_mono():
    """Guided 2 / Your Turn 2: -18m^4n^2 / (24mn^5)."""
    vs = random.choice(VAR_PAIRS)
    g = random.randint(2, 8)
    u, v = random.sample(range(1, 7), 2)
    if math.gcd(u, v) != 1:
        return None
    ct, cb = g * u * random.choice([1, 1, -1]), g * v * random.choice([1, 1, 1, -1])
    et = [random.randint(1, 6) for _ in vs]
    eb = [random.randint(1, 6) for _ in vs]
    d = [a - b for a, b in zip(et, eb)]
    if not any(d):
        return None
    c = F(ct, cb)
    right = monofrac(c, d, vs)
    traps = [monofrac(c, [-d[0], d[1]], vs), monofrac(c, [d[0], -d[1]], vs), monofrac(c, [-x for x in d], vs),
             monofrac(c, [a + b for a, b in zip(et, eb)], vs),        # added the exponents
             monofrac(1 / c, d, vs), monofrac(-c, d, vs),
             monofrac(F(ct, cb) * g if abs(ct) // g > 1 else F(ct, cb) / g, d, vs)]   # divided out the wrong number
    text = random.choice(["Simplify:  {}", "Simplify fully:  {}"]).format(
        "{%s|%s}" % (mono_text(ct, et, vs), mono_text(cb, eb, vs)))
    return pack(text, right, traps)


def _cancel_terms(num, den):
    """The classic mistake: crossing out the x^2 terms (and maybe the signs) - cancelling TERMS."""
    if num.deg() != 2 or den.deg() != 2 or num.coef(2) != den.coef(2):
        return None
    n2, d2 = num - num.lead(), den - den.lead()
    if d2.is_zero() or n2.is_zero():
        return None
    if n2.t[n2._order()[0]] < 0 and d2.t[d2._order()[0]] < 0:
        n2, d2 = -n2, -d2
    return "{%s|%s}" % (n2.text(), d2.text()), sig(n2, d2)


def base_cancel():
    """Guided 3: (x^2 - 3x - 18)/(x^2 - 36) = (x + 3)/(x + 6).  Returns the problem and its answers."""
    ks = random.sample([i for i in range(-9, 10)], 3)
    k0, kn, kd = ks
    if random.random() < 0.2:
        k0 = 0                                         # a common factor of x: (x^2 + 3x)/(x^2 - 2x)
        if 0 in (kn, kd):
            return None
    cn, cd = random.choice([1, 1, 1, 1, 2, 3]), random.choice([1, 1, 1, 1, 2, 3])
    nF = Fac(cn, [(1, k0), (1, kn)])
    dF = Fac(cd, [(1, k0), (1, kd)])
    num, den = nF.poly(), dF.poly()
    if max(abs(v) for v in list(num.t.values()) + list(den.t.values())) > 80:
        return None
    a = opt_f(nF, dF)
    sn, sd = Fac(cn, [(1, kn)]), Fac(cd, [(1, kd)])
    wrong = [opt_f(Fac(cn, [(1, -kn)]), Fac(cd, [(1, -kd)])),       # signs of the factors
             opt_f(Fac(cn, [(1, -kn)]), sd), opt_f(sn, Fac(cd, [(1, -kd)])),
             opt_f(sd, sn),                                          # upside down
             opt_f(Fac(cn, [(1, k0)]), sd) if k0 != kn else None,     # cancelled the wrong factor
             _cancel_terms(num, den)]
    if kn and kd:                                                    # "cancelled the x's" too
        v = F(cn * kn, cd * kd)
        wrong.append((fmt(v), sig(Poly.const(v), Poly.const(1))))
    return dict(num=num, den=den, ans=a, wrong=wrong, npv=dF.roots(), npv_simple=sd.roots())


def base_gcf():
    """Your Turn 3: (x^2 - 81)/(x^3 + 9x^2) = (x - 9)/x^2  (or upside down: x^4 - x^3 over x^2 - 1)."""
    k = nz(-9, 9)
    p = random.choice([1, 2, 2])
    m = random.choice([-k, nz(-9, 9, avoid=(k,))])        # difference of squares, or another factor
    top = Fac(1, [(1, k), (1, m)])
    bot = Fac(1, [((1, 0), p), (1, k)])
    if random.random() < 0.3:
        top, bot = bot, top
    num, den = top.poly(), bot.poly()
    a = opt_f(top, bot)
    n2, d2 = cancel(top, bot)
    flip = lambda f: Fac(f.c, [((a_, -b_), e) if (a_, b_) != (1, 0) else ((a_, b_), e) for (a_, b_), e in f.f.items()])
    lower = lambda f: Fac(f.c, [((a_, b_), (e - 1 if (a_, b_) == (1, 0) and e > 1 else e)) for (a_, b_), e in f.f.items()])
    wrong = [opt_f(flip(n2), d2), opt_f(n2, flip(d2)), opt_f(lower(n2), lower(d2)),     # lost a power of x
             opt_f(d2, n2), opt_f(flip(n2), flip(d2)), _cancel_terms(num, den)]
    return dict(num=num, den=den, ans=a, wrong=wrong, npv=bot.roots(), npv_simple=d2.roots())


def base_opp():
    """Guided 4: (3x^2 - 7x + 2)/(4 - x^2) = -(3x - 1)/(x + 2).  Opposites cancel to -1."""
    k = random.randint(1, 9)
    A = random.choice([1, 1, 2, 3])
    B = nz(-9, 9)
    if math.gcd(A, abs(B)) != 1 or (A, B) in ((1, k), (1, -k)):
        return None
    other = (A, B)
    shape = random.random()
    if shape < 0.45:                   # (Ax + B)(x - k) / (k^2 - x^2)
        top, bot = Fac(1, [other, (1, -k)]), Fac(1, [(-1, k), (1, k)])
    elif shape < 0.75:                 # (k^2 - x^2) / ((Ax + B)(x - k))
        top, bot = Fac(1, [(-1, k), (1, k)]), Fac(1, [other, (1, -k)])
    else:                              # (Ax + B)(x - k) / (k - x)
        top, bot = Fac(1, [other, (1, -k)]), Fac(1, [(-1, k)])
    num, den = top.poly(), bot.poly()
    if max(abs(v) for v in num.t.values()) > 60:
        return None
    a = opt_f(top, bot)
    n2, d2 = cancel(top, bot)
    pos = lambda f: Fac(abs(f.c), f.f.items())
    flip = lambda f: Fac(f.c, [((a_, -b_), e) for (a_, b_), e in f.f.items()])
    wrong = [opt_f(pos(n2), pos(d2)),                     # forgot the -1
             opt_f(pos(d2), pos(n2)), opt_f(d2, n2),
             opt_f(flip(n2), d2), opt_f(n2, flip(d2)) if d2.f else None,
             opt_f(pos(flip(n2)), pos(d2)),
             opt_f(pos(n2), pos(flip(d2))) if d2.f else None]
    return dict(num=num, den=den, ans=a, wrong=wrong, npv=bot.roots(), npv_simple=d2.roots())


def base_none():
    """DeltaMath 'nothing cancels': (x^2 + 2x - 24)/(x^2 - 8x + 15) = (x + 6)(x - 4)/((x - 3)(x - 5))."""
    ks = random.sample([i for i in range(-9, 10) if i], 4)
    top, bot = Fac(1, [(1, ks[0]), (1, ks[1])]), Fac(1, [(1, ks[2]), (1, ks[3])])
    num, den = top.poly(), bot.poly()
    flip = lambda f: Fac(f.c, [((a_, -b_), e) for (a_, b_), e in f.f.items()])
    one = lambda f: Fac(f.c, [((1, -ks[0]), 1), ((1, ks[1]), 1)]) if f is top else f
    a = (frac_text(top, bot), sigf(top, bot))
    wrong = [(frac_text(flip(top), bot), sigf(flip(top), bot)), (frac_text(top, flip(bot)), sigf(top, flip(bot))),
             (frac_text(one(top), bot), sigf(one(top), bot)),
             opt_f(Fac(1, [(1, ks[0])]), Fac(1, [(1, ks[2])])),        # "cancelled" factors that only look alike
             opt_f(Fac(1, [(1, ks[1])]), Fac(1, [(1, ks[3])])),
             _cancel_terms(num, den)]
    pairs = wrong_pairs(-ks[0], -ks[1])
    if pairs:
        m, kk = pairs[0]
        w = Fac(1, [(1, -m), (1, -kk)])
        wrong.append((frac_text(w, bot), sigf(w, bot)))
    return dict(num=num, den=den, ans=a, wrong=wrong, npv=bot.roots(), npv_simple=bot.roots())


def q51_simplify(base, with_npv=False):
    b = base()
    if b is None:
        return None
    ex = "{%s|%s}" % (b["num"].show(), b["den"].show())
    if not with_npv:
        text = random.choice(["Simplify:  {}", "Simplify fully:  {}", "{}.  Simplify."]).format(ex)
        return pack(text, b["ans"], b["wrong"])
    # Simplify AND state the NPVs (from the ORIGINAL).  A 2 x 2 grid: {right, wrong answer} x
    # {NPVs from the original, NPVs from the simplified answer only}, plus one more.
    R, Rs = b["npv"], b["npv_simple"]
    both = lambda ans, vals: (f"{ans[0]},   {npv_text(vals)}", (ans[1], frozenset(vals)))
    wrong_ans = [w for w in b["wrong"] if w is not None]
    if not wrong_ans:
        return None
    w1 = wrong_ans[0] if random.random() < 0.6 else random.choice(wrong_ans)
    flipped = {-v for v in R}
    traps = [both(b["ans"], Rs) if Rs != R else both(b["ans"], flipped),
             both(w1, R), both(w1, Rs if Rs != R else flipped)]
    traps += [both(b["ans"], flipped), both(random.choice(wrong_ans), R), both(b["ans"], R | {-v for v in Rs})]
    text = random.choice(["Simplify and state the NPVs:  {}", "{}.  Simplify; state the NPVs."]).format(ex)
    return pack(text, both(b["ans"], R), traps)


def gen_51():
    kind = random.choices(["npv", "mono", "cancel", "gcf", "opp", "none", "both"],
                          weights=[20, 12, 18, 12, 14, 8, 16])[0]
    if kind == "npv":
        return q51_npv()
    if kind == "mono":
        return q51_mono()
    if kind == "both":
        return q51_simplify(random.choice([base_cancel, base_cancel, base_gcf, base_opp]), with_npv=True)
    return q51_simplify({"cancel": base_cancel, "gcf": base_gcf, "opp": base_opp, "none": base_none}[kind])


# ==========================================
# 6.  5.2 MULTIPLYING + DIVIDING
# ==========================================
def q52_mono():
    """Guided 1 / Your Turn 1-2: 8m^3/(15n) * 9n^2/(4m) = 6m^2n/5  (or divided)."""
    vs = random.choice(VAR_PAIRS)
    mon = lambda: [random.randint(0, 4) for _ in vs]
    ms = []
    for _ in range(4):
        e = mon()
        if not any(e):
            e[random.randrange(2)] = random.randint(1, 3)
        ms.append((random.randint(2, 15) * (-1 if random.random() < 0.12 else 1), e))
    (c1, e1), (c2, e2), (c3, e3), (c4, e4) = ms
    div = random.random() < 0.45
    val = lambda a, b, c, d: (F(a[0] * c[0], b[0] * d[0]), [a[1][i] + c[1][i] - b[1][i] - d[1][i] for i in range(2)])
    if div:
        cv, ev = val(ms[0], ms[1], ms[3], ms[2])
        cw, ew = val(ms[0], ms[1], ms[2], ms[3])          # forgot to flip
        cx, ex_ = val(ms[1], ms[0], ms[2], ms[3])          # flipped the first one instead
    else:
        cv, ev = val(ms[0], ms[1], ms[2], ms[3])
        cw, ew = val(ms[0], ms[1], ms[3], ms[2])          # multiplied by the reciprocal
        cx, ex_ = cv, [ev[0] + 1, ev[1]]
    if cv.numerator > 60 or cv.denominator > 60 or not any(ev):
        return None
    right = monofrac(cv, ev, vs)
    traps = [monofrac(cw, ew, vs), monofrac(cx, ex_, vs), monofrac(1 / cv, ev, vs), monofrac(cv, [-ev[0], ev[1]], vs),
             monofrac(cv, [ev[0], -ev[1]], vs), monofrac(-cv, ev, vs), monofrac(cv, [-v for v in ev], vs)]
    f = lambda c, e: "{%s|%s}" % (mono_text(c[0], c[1], vs), mono_text(e[0], e[1], vs))
    text = f"Simplify:  {f(ms[0], ms[1])} {DIV if div else DOT} {f(ms[2], ms[3])}"
    return pack(text, right, traps)


def _slot_poly(fac):
    return fac.poly()


def product_problem(div=False, opp=False):
    """Two rational expressions multiplied (or divided) whose factors cancel.
    Returns dict: the four displayed parts and the answer (Fac top, Fac bottom), and the pieces for mistakes."""
    for _ in range(60):
        n_cancel = random.choice([2, 2, 3])
        n_surv = random.choice([1, 2, 2])
        ks = random.sample(range(-9, 10), n_cancel + n_surv)
        atoms = [(1, k) for k in ks]
        slots = {"nA": [], "dA": [], "nB": [], "dB": []}
        for at in atoms[:n_cancel]:
            top = random.choice(["nA", "nB"])
            bot = random.choice(["dB", "dB", "dA"] if top == "nA" else ["dA", "dA", "dB"])
            slots[top].append(at)
            slots[bot].append(at)
        for at in atoms[n_cancel:]:
            slots[random.choice(list(slots))].append(at)
        if any(len(v) > 2 for v in slots.values()):
            continue
        consts = {s: random.choice([1, 1, 1, 1, 2, 3, 4, 5, 6]) for s in slots}
        for s in slots:                                # an empty slot becomes a monomial like 3x
            if not slots[s]:
                slots[s] = [(1, 0)] * random.choice([1, 1, 2])
                consts[s] = random.randint(2, 6)
        opp_atom = None
        if opp:                                        # one numerator factor written backwards: (2 - x)
            cands = [(s, at) for s in ("nA", "nB") for at in slots[s] if at[1] < 0 and at in atoms[:n_cancel]]
            if not cands:
                continue
            opp_s, opp_atom = random.choice(cands)
            if random.random() < 0.5:                  # ... or a denominator one
                for s in ("dA", "dB"):
                    if opp_atom in slots[s]:
                        opp_s = s
        facs = {}
        for s, ats in slots.items():
            f = Fac(consts[s])
            for at in ats:
                if opp_atom is not None and s == opp_s and at == opp_atom:
                    f.add((-1, -at[1]))               # (k - x) = -(x - k)
                else:
                    f.add(at)
            facs[s] = f
        polys = {s: f.poly() for s, f in facs.items()}
        if any(p.deg() > 3 or max(abs(v) for v in p.t.values()) > 60 for p in polys.values()):
            continue
        n = facs["nA"].times(facs["nB"])
        d = facs["dA"].times(facs["dB"])
        an, ad = cancel(n, d)
        if an.c.denominator != 1 and ad.c.denominator != 1:
            pass
        r = F(an.c, ad.c)
        if r.numerator > 30 or r.denominator > 30:
            continue
        if sum(an.f.values()) + sum(ad.f.values()) == 0:
            continue
        return dict(facs=facs, polys=polys, an=an, ad=ad, div=div, opp=opp_atom is not None)
    return None


def q52_product(div=False, opp=False, ask_npv=False):
    """Guided 2-4 / Your Turn 3-6: factor, cancel, multiply (dividing = multiply by the reciprocal)."""
    pr = product_problem(div, opp)
    if pr is None:
        return None
    fs, ps = pr["facs"], pr["polys"]
    show = lambda s: ps[s].show()
    if div:      # what is SHOWN:  nA/dA  divided by  dB/nB   (= nA/dA times nB/dB)
        ex = f"{{{show('nA')}|{show('dA')}}} {DIV} {{{show('dB')}|{show('nB')}}}"
    else:
        ex = f"{{{show('nA')}|{show('dA')}}} {DOT} {{{show('nB')}|{show('dB')}}}"
    if ask_npv:
        # NPVs: every denominator shown, and (dividing) the divisor's numerator too
        shown_dens = [fs["dA"], fs["nB"] if div else fs["dB"]]
        R = set().union(*(f.roots() for f in shown_dens))
        if div:
            R |= fs["dB"].roots()
        miss = set().union(*(f.roots() for f in shown_dens))
        traps = [npv_opt(miss) if miss != R else None,                       # forgot the divisor's numerator
                 npv_opt(pr["ad"].roots()),                                    # from the answer only
                 npv_opt({-v for v in R}), npv_opt(R | fs["nA"].roots()),
                 npv_opt(fs["dA"].roots() | fs["dB"].roots()) if div else npv_opt(fs["dA"].roots()),
                 npv_opt({-v for v in miss})]
        text = random.choice(["Find the NPVs:  {}", "State the NPVs:  {}"]).format(ex)
        return pack(text, npv_opt(R), traps)
    an, ad = pr["an"], pr["ad"]
    right = opt_f(an, ad)
    pos = lambda f: Fac(abs(f.c), f.f.items())
    traps = []
    if div:                                            # forgot to flip
        n = fs["nA"].times(fs["dB"])
        d = fs["dA"].times(fs["nB"])
        traps.append(opt_f(n, d))
    if pr["opp"]:
        traps.append(opt_f(Fac(-an.c, an.f.items()), ad))                    # forgot the -1
    traps.append(opt_f(ad, an))                                               # upside down
    for f, g in ((an, ad), (ad, an)):                                        # one sign slip in a factor left
        for ab in list(f.f):
            if ab[1] != 0:
                h = f.copy()
                h.add(ab, -1)
                h.add((ab[0], -ab[1]))
                traps.append(opt_f(h, g) if f is an else opt_f(g, h))
                break
    for ab in list(an.f) + list(ad.f):                                       # cancelled one factor too many
        if ab in an.f:
            h = an.copy()
            h.add(ab, -1)
            traps.append(opt_f(h, ad))
        else:
            h = ad.copy()
            h.add(ab, -1)
            traps.append(opt_f(an, h))
    if an.c / ad.c not in (1, -1):
        traps.append(opt_f(Fac(ad.c, an.f.items()), Fac(an.c, ad.f.items())))   # the number upside down
    keep = 2 if div else 1                             # the most important mistakes stay first
    rest = traps[keep:]
    random.shuffle(rest)
    traps = traps[:keep] + rest
    text = random.choice(["Simplify:  {}", "Simplify fully:  {}"]).format(ex)
    return pack(text, right, traps)


def gen_52():
    kind = random.choices(["mono", "mult", "div", "opp", "npv"], weights=[16, 24, 26, 18, 16])[0]
    if kind == "mono":
        return q52_mono()
    if kind == "mult":
        return q52_product()
    if kind == "div":
        return q52_product(div=True, opp=random.random() < 0.25)
    if kind == "opp":
        return q52_product(div=random.random() < 0.4, opp=True)
    return q52_product(div=random.random() < 0.75, ask_npv=True)


# ==========================================
# 7.  5.3 ADDING + SUBTRACTING I  (monomial denominators)
# ==========================================
def _mono_den(d, m, vs=("x",), ms=None):
    """Poly d * x^m  (or d * a^i * b^j)."""
    exps = ms if ms is not None else (m,)
    return Poly({tuple(exps): d}, vs)


def mono_den_text(d, exps, vs):
    return mono_text(d, exps, vs, sign=False)


def add_monomial(terms, vs=("x",)):
    """terms: [(sign, numerator Poly, d, exps)].  Returns the answer and the usual mistakes, as (text, key)."""
    L = 1
    for _, _, d, _ in terms:
        L = L * d // math.gcd(L, d)
    M = [max(t[3][i] for t in terms) for i in range(len(vs))]
    lcd = Poly({tuple(M): L}, vs)
    num = Poly.const(0, vs)
    parts = []                                          # each numerator times what its denominator is missing
    for s, n, d, e in terms:
        mult = Poly({tuple(M[i] - e[i] for i in range(len(vs))): L // d}, vs)
        parts.append((s, n * mult, n, mult))
        num = num + s * (n * mult)
    if num.is_zero():
        return None

    def as_text(n, den_c, den_e):
        """n / (den_c * vars^den_e), reduced (common number, common power), sign in front."""
        if n.is_zero():
            return None
        g = math.gcd(n.content(), den_c)
        lo = [min([k[i] for k in n.t] + [den_e[i]]) for i in range(len(vs))]
        n2 = Poly({tuple(k[i] - lo[i] for i in range(len(vs))): v / g for k, v in n.t.items()}, vs)
        de = [den_e[i] - lo[i] for i in range(len(vs))]
        dc = den_c // g
        neg = n2.t[n2._order()[0]] < 0                 # a negative top: the minus goes in front
        if neg:
            n2 = -n2
        top = n2.text()
        bot = mono_den_text(dc, de, vs) if (dc != 1 or any(de)) else ""
        s = over(top, bot)
        if neg and not bot and len(n2.t) > 1:
            s = f"({s})"
        return (MINUS if neg else "") + s, sig(n2 * (-1 if neg else 1), Poly({tuple(de): dc}, vs))

    right = as_text(num, L, M)
    traps = []
    unscaled = Poly.const(0, vs)                        # forgot to multiply the numerators
    for s, sc, n, mult in parts:
        unscaled = unscaled + s * n
    traps.append(as_text(unscaled, L, M))
    for i in range(len(parts)):                          # multiplied only some of them
        w = Poly.const(0, vs)
        for j, (s, sc, n, mult) in enumerate(parts):
            w = w + s * (sc if j != i else n)
        traps.append(as_text(w, L, M))
    for i in range(len(parts)):                          # multiplied by the number but not the variable part
        w = Poly.const(0, vs)
        for j, (s, sc, n, mult) in enumerate(parts):
            if j == i and len(mult.t) == 1 and sum(list(mult.t)[0]) > 0:
                w = w + s * (n * list(mult.t.values())[0])
            else:
                w = w + s * sc
        traps.append(as_text(w, L, M))
    for i, (s, sc, n, mult) in enumerate(parts):         # subtracting: only the first term changed sign
        if s < 0 and len(sc.t) > 1:
            w = Poly.const(0, vs)
            for j, (s2, sc2, n2, m2) in enumerate(parts):
                w = w + (s2 * sc2 if j != i else (-sc2.lead() + (sc2 - sc2.lead())))
            traps.insert(0, as_text(w, L, M))
    prod_c, prod_e = 1, [0] * len(vs)                   # the product of the denominators as the LCD
    for _, _, d, e in terms:
        prod_c *= d
        prod_e = [prod_e[i] + e[i] for i in range(len(vs))]
    if (prod_c, prod_e) != (L, M):
        traps.append(as_text(num, prod_c, prod_e))
    if all(t[0] > 0 for t in terms) and len(terms) == 2 and all(len(t[1].t) == 1 and sum(list(t[1].t)[0]) == 0 for t in terms):
        # added straight across: (a + b)/(d1 x^m1 + d2 x^m2)
        top = terms[0][1] + terms[1][1]
        bot = _mono_den(terms[0][2], 0, vs, terms[0][3]) + _mono_den(terms[1][2], 0, vs, terms[1][3])
        if bot.deg() >= 1 and len(bot.t) == 2:
            traps.insert(0, (over(top.text(), bot.text()), sig(top, bot)))
    return right, traps


def _term_text(s, n, d, e, vs, first):
    """One term:  + {x + 4|6x}  or  2x  (no denominator)."""
    nt = n.text()
    if d == 1 and not any(e):
        body = f"({nt})" if (len(n.t) > 1 and not first) else nt
    else:
        body = "{%s|%s}" % (nt, mono_den_text(d, e, vs))
    if first:
        return (MINUS if s < 0 else "") + body
    return (f" {MINUS} " if s < 0 else " + ") + body


def q53():
    shape = random.choices(["const", "binom", "whole", "three", "twovar"], weights=[26, 26, 16, 16, 16])[0]
    vs = ("x",)
    terms = []
    if shape == "const":            # 3/(4x) + 5/(6x^2)
        for i in range(2):
            terms.append((1 if i == 0 or random.random() < 0.5 else -1, Poly.const(random.randint(1, 9)),
                          random.randint(2, 12), (random.choice([1, 1, 2, 2, 3]),)))
    elif shape == "binom":          # (x + 4)/(6x) - (x - 2)/(4x^2)
        for i in range(2):
            terms.append((1 if i == 0 or random.random() < 0.4 else -1, lin(1, nz(-9, 9)),
                          random.randint(2, 12), (random.choice([1, 1, 2]),)))
    elif shape == "whole":          # 2x + 3/(4x)  or  4 + 1/(3x)
        w = Poly({(random.choice([0, 1, 1]),): nz(-6, 6)})
        terms.append((1, w, 1, (0,)))
        terms.append((random.choice([1, -1]), Poly.const(random.randint(1, 9)), random.randint(2, 9),
                      (random.choice([1, 1, 2]),)))
        if random.random() < 0.5:
            terms.reverse()
            terms[0] = (1, terms[0][1], terms[0][2], terms[0][3])
    elif shape == "three":          # 1/2 + 3/(5y) - (y - 4)/(10y^2)
        terms.append((1, Poly.const(random.randint(1, 5)), random.randint(2, 6), (0,)))
        terms.append((random.choice([1, -1]), Poly.const(random.randint(1, 9)), random.randint(2, 6), (1,)))
        terms.append((random.choice([1, -1]), lin(1, nz(-9, 9)), random.randint(2, 12), (2,)))
    else:                           # 2/(9a^2b) - 5/(6ab^3)
        vs = random.choice(VAR_PAIRS)
        for i in range(2):
            e = (random.randint(0, 3), random.randint(0, 3))
            if not any(e):
                e = (1, 1)
            terms.append((1 if i == 0 or random.random() < 0.5 else -1,
                          Poly.const(random.randint(1, 9), vs), random.randint(2, 12), e))
        if terms[0][3] == terms[1][3]:
            return None
    if shape in ("const", "binom") and terms[0][2:] == terms[1][2:]:
        return None
    for s, n, d, e in terms:                         # a number on top shares nothing with its bottom (like 9/(3x))
        if len(n.t) == 1 and sum(list(n.t)[0]) == 0 and math.gcd(int(list(n.t.values())[0]), d) != 1:
            return None
    out = add_monomial(terms, vs)
    if out is None:
        return None
    right, traps = out
    if right is None or len(right[0]) > 60:
        return None
    ex = "".join(_term_text(s, n, d, e, vs, i == 0) for i, (s, n, d, e) in enumerate(terms))
    text = random.choice(["Simplify:  {}", "Simplify:  {}", "Write as one fraction:  {}"]).format(ex)
    return pack(text, right, traps)


def gen_53():
    return q53()


# ==========================================
# 8.  5.4 ADDING + SUBTRACTING II  (binomial and trinomial denominators)
# ==========================================
def add_factored(terms):
    """terms: [(sign, numerator Poly, denominator Fac)].  Returns the answer and the usual mistakes."""
    lcd = Fac(1)
    for _, _, d in terms:
        for ab, k in d.f.items():
            if lcd.f.get(ab, 0) < k:
                lcd.add(ab, k - lcd.f.get(ab, 0))
    parts, N = [], Poly.const(0)
    for s, n, d in terms:
        miss = Fac(1 / d.c)
        for ab, k in lcd.f.items():
            if k - d.f.get(ab, 0):
                miss.add(ab, k - d.f.get(ab, 0))
        sc = n * miss.poly()
        parts.append((s, sc, n, d, miss))
        N = N + s * sc

    def finish(num):
        """Cancel any factor the top shares with the LCD; (text, key)."""
        if num.is_zero():
            return None
        den = lcd.copy()
        for ab in list(den.f):
            while den.f.get(ab, 0):
                q = divide_lin(num, *ab)
                if q is None:
                    break
                num = q
                den.add(ab, -1)
        return poly_over_fac(num, den), sig(num, den.poly())

    right = finish(N)
    traps = []
    for i, (s, sc, n, d, miss) in enumerate(parts):      # subtracting: only the first term's sign changed
        if s < 0 and len(sc.t) > 1:
            w = N + sc + (-sc.lead() + (sc - sc.lead()))
            traps.append(finish(w))
    traps.append(finish(sum((s * n * (1 / d.c) for s, _, n, d, _ in parts), Poly.const(0))))   # forgot to multiply
    for i in range(len(parts)):                          # multiplied only one of them
        w = Poly.const(0)
        for j, (s, sc, n, d, miss) in enumerate(parts):
            w = w + (s * sc if j != i else s * n * (1 / d.c))
        traps.append(finish(w))
    for i, (s, sc, n, d, miss) in enumerate(parts):      # opposites: ignored the -1 of (k - x)
        if d.c < 0:
            traps.insert(0, finish(N - 2 * s * sc))
    for i, (s, sc, n, d, miss) in enumerate(parts):      # a slip multiplying out: wrong sign on the number
        c0 = sc.coef(0)
        if c0 != 0 and len(sc.t) > 1:
            traps.append(finish(N - 2 * s * Poly.const(c0)))
    if len(terms) == 2 and all(d.f for _, _, d in terms):  # added straight across
        top = terms[0][1] + terms[1][0] * terms[1][1]
        bot = terms[0][2].poly() + terms[1][2].poly()
        if not bot.is_zero() and bot.deg() >= 1 and not top.is_zero():
            traps.append((over(top.text(), bot.text()), sig(top, bot)))
    return right, traps


def _ftext(s, n, d, first):
    """One term of a 5.4 problem."""
    if not d.f and d.c == 1:
        nt = n.show()
        body = f"({nt})" if len(n.t) > 1 else nt
    else:
        body = "{%s|%s}" % (n.show(), d.poly().show())
    if first:
        return (MINUS if s < 0 else "") + body
    return (f" {MINUS} " if s < 0 else " + ") + body


def q54():
    """The 6 DeltaMath Level 2 types (and the booklet's 5.4)."""
    kind = random.choices(["two", "factor", "opp", "tri", "xden", "whole"], weights=[20, 18, 18, 16, 14, 14])[0]
    sgn = lambda: random.choice([1, -1])
    if kind == "two":               # (x + 2)/(x - 3) + (x - 1)/(x + 4)
        p, q = random.sample([i for i in range(-9, 10) if i], 2)
        terms = [(1, lin(1, nz(-9, 9)), Fac(1, [(1, p)])), (sgn(), lin(1, nz(-9, 9)), Fac(1, [(1, q)]))]
        if random.random() < 0.4:
            terms[1] = (terms[1][0], Poly.const(random.randint(1, 9)), terms[1][2])
    elif kind == "factor":          # 3/(x - 2) - 12/(x^2 - 4): sometimes the answer cancels
        p, q = random.sample([i for i in range(-9, 10) if i], 2)
        if random.random() < 0.3:
            q = -p
        c = random.randint(1, 6)
        s = sgn()
        d = -s * c * (q - p) if random.random() < 0.5 else nz(-15, 15)    # half the time (x + p) cancels at the end
        if d == 0:
            return None
        terms = [(1, Poly.const(c), Fac(1, [(1, p)])), (s if d > 0 else -s, Poly.const(abs(d)), Fac(1, [(1, p), (1, q)]))]
    elif kind == "opp":             # (x + 1)/(x - 3) + 24/(9 - x^2)   or   3x/(x - 7) + 21/(7 - x)
        k = random.randint(1, 9)
        if random.random() < 0.5:
            terms = [(1, lin(1, nz(-9, 9)), Fac(1, [(1, -k)])),
                     (sgn(), Poly.const(random.randint(2, 30)), Fac(1, [(-1, k), (1, k)]))]
        else:
            a = random.randint(2, 6)
            terms = [(1, Poly({(1,): a}), Fac(1, [(1, -k)])),
                     (sgn(), Poly.const(random.choice([a * k, random.randint(2, 30)])), Fac(1, [(-1, k)]))]
    elif kind == "tri":             # (x + 1)/(x^2 - x - 6) - (x - 2)/(x^2 + 5x + 6)
        p, q, r = random.sample([i for i in range(-7, 8) if i], 3)
        terms = [(1, lin(1, nz(-6, 6)), Fac(1, [(1, p), (1, q)])),
                 (sgn(), lin(1, nz(-6, 6)), Fac(1, [(1, p), (1, r)]))]
    elif kind == "xden":            # (x + 5)/x - 2/(x - 3)
        q = nz(-9, 9)
        terms = [(1, lin(1, nz(-9, 9)), Fac(1, [(1, 0)])), (sgn(), Poly.const(random.randint(1, 9)), Fac(1, [(1, q)]))]
        if random.random() < 0.5:
            terms = [(1, lin(1, nz(-9, 9)), Fac(1, [(1, q)])), (sgn(), Poly.const(random.randint(1, 9)), Fac(1, [(1, 0)]))]
    else:                           # (x + 3) - 2x/(x + 4)   (DeltaMath: a polynomial with no denominator)
        q = nz(-9, 9)
        whole = lin(random.choice([1, 1, 2, 3]), nz(-9, 9))
        frac_top = Poly({(1,): random.randint(1, 6)}) if random.random() < 0.6 else Poly.const(random.randint(1, 9))
        terms = [(1, whole, Fac(1)), (sgn(), frac_top, Fac(1, [(1, q)]))]
        if random.random() < 0.4:
            terms.reverse()
            terms = [(1, terms[0][1], terms[0][2]), (sgn(), terms[1][1], terms[1][2])]
    for _, n, d in terms:
        if d.f and any(abs(v) > 60 for v in d.poly().t.values()):
            return None
        if any(divide_lin(n, *ab) is not None for ab in d.f):     # a fraction that simplifies by itself
            return None
    out = add_factored(terms)
    right, traps = out
    if right is None or len(right[0]) > 70:
        return None
    ex = "".join(_ftext(s, n, d, i == 0) for i, (s, n, d) in enumerate(terms))
    text = random.choice(["Simplify:  {}", "Simplify:  {}", "Write as one fraction:  {}"]).format(ex)
    return pack(text, right, traps)


def gen_54():
    return q54()


# ==========================================
# 9.  5.5 SOLVING RATIONAL EQUATIONS
# ==========================================
def solve_eq(left, right):
    """left/right: [(numerator Poly, denominator Fac)].  Multiply every term by the LCD and solve.
    Returns (solutions, rejected, NPVs, the polynomial) or None if it doesn't come out nicely."""
    lcd = Fac(1)
    for _, d in left + right:
        for ab, k in d.f.items():
            if lcd.f.get(ab, 0) < k:
                lcd.add(ab, k - lcd.f.get(ab, 0))
    L = lcd.poly()

    def times_lcd(n, d, skip_whole=False):
        if skip_whole and not d.f:
            return n * (1 / d.c)                       # the mistake: a whole term NOT multiplied by the LCD
        miss = Fac(1 / d.c)
        for ab, k in lcd.f.items():
            if k - d.f.get(ab, 0):
                miss.add(ab, k - d.f.get(ab, 0))
        return n * miss.poly()

    def poly_of(skip_whole=False):
        p = Poly.const(0)
        for n, d in left:
            p = p + times_lcd(n, d, skip_whole)
        for n, d in right:
            p = p - times_lcd(n, d, skip_whole)
        return p

    npv = lcd.roots()

    def roots_of(p):
        if p.deg() < 1:
            return None
        rs = rational_roots(p)
        if rs is None:
            return None
        return [r for r in rs if r not in npv], [r for r in rs if r in npv]

    p = poly_of()
    main = roots_of(p)
    if main is None:
        return None
    skip = roots_of(poly_of(skip_whole=True)) if any(not d.f for _, d in left + right) else None
    if skip and not all(abs(v) <= 15 and v.denominator <= 3 for v in skip[0] + skip[1]):
        skip = None                                    # (a strange-looking wrong answer gives itself away)
    return dict(sols=main[0], rej=main[1], npv=npv, poly=p, skip=skip, lcd=L)


def _eq_text(left, right, signs_l=None, signs_r=None):
    def side(terms):
        out = ""
        for i, (n, d) in enumerate(terms):
            c = 1
            if n.t and n.t[n._order()[0]] < 0 and len(n.t) == 1:   # a negative number on top: minus in front
                n, c = -n, -1
            if not d.f and d.c == 1:
                body = n.show() if (len(n.t) == 1 or i == 0) else f"({n.show()})"
            else:
                body = "{%s|%s}" % (n.show(), d.poly().show())
            out += ((MINUS if c < 0 else "") if i == 0 else (f" {MINUS} " if c < 0 else " + ")) + body
        return out
    return f"{side(left)} = {side(right)}"


def nice_roots(info, lim=12):
    if info is None:
        return False
    vals = info["sols"] + info["rej"]
    return bool(vals) and all(abs(v) <= lim and v.denominator in (1, 2, 3) for v in vals)


def eq_monomial():
    """Guided 1: 1/x + 1/(3x) = 2/3  (linear)  or  Your Turn 1: 3/x - 1/4 = 5/(2x)."""
    x0 = F(nz(-9, 9))
    for _ in range(40):
        a, b, k = nz(-9, 9), nz(-9, 9), random.randint(2, 5)
        lhs_val = F(a) / x0 + F(b) / (k * x0)              # a/x + b/(kx) at x0
        if lhs_val == 0:
            continue
        left = [(Poly.const(a), Fac(1, [(1, 0)])), (Poly.const(b), Fac(k, [(1, 0)]))]
        if random.random() < 0.5:                         # = p/q
            right = [(Poly.const(lhs_val.numerator), Fac(lhs_val.denominator))]
        else:                                             # a/x - p/q = c/(m x): a number on the left instead
            q = random.randint(2, 6)
            pnum = nz(-9, 9)
            rhs = (F(a) / x0 - F(pnum, q)) * x0           # = c/m
            if rhs == 0:
                continue
            left = [(Poly.const(a), Fac(1, [(1, 0)])), (Poly.const(-pnum), Fac(q))]
            right = [(Poly.const(rhs.numerator), Fac(rhs.denominator, [(1, 0)]))]
        info = solve_eq(left, right)
        if nice_roots(info) and len(info["sols"]) == 1:
            return left, right, info
    return None


def eq_quadratic_mono():
    """Guided 2: 1 - 2/x = 15/x^2   or   Your Turn 2: 2 + 5/x = 3/x^2  (a != 1: SDRF)."""
    if random.random() < 0.6:
        r, s = random.sample([i for i in range(-9, 10) if i], 2)
        A, B, C = 1, -(r + s), r * s                       # x^2 + Bx + C = 0  ->  1 + B/x = -C/x^2
    else:
        A = random.choice([2, 3])
        u, r = nz(-5, 5), nz(-6, 6)
        if math.gcd(A, abs(u)) != 1:
            return None
        B, C = -(u + A * r), u * r                         # (Ax - u)(x - r)
    if B == 0 or C == 0:
        return None
    left = [(Poly.const(A), Fac(1)), (Poly.const(B), Fac(1, [(1, 0)]))]
    right = [(Poly.const(-C), Fac(1, [((1, 0), 2)]))]
    return left, right, solve_eq(left, right)


def eq_cross():
    """Guided 3: x/(x + 2) = 3/(x - 2)   /   Your Turn 4: (x - 3)/x = 4/(x + 5)."""
    for _ in range(80):
        r, s = random.sample([i for i in range(-9, 10) if i], 2)
        m, c = random.randint(-6, 6), random.randint(-6, 6)
        b = r + s + m + c                                  # (x + m)(x + c) = b(x + a)
        if b == 0 or (m * c - r * s) % b:
            continue
        a = (m * c - r * s) // b
        if a == c or m == a or abs(a) > 9:
            continue
        left = [(lin(1, m), Fac(1, [(1, a)]))]
        right = [(Poly.const(b), Fac(1, [(1, c)]))]
        info = solve_eq(left, right)
        if nice_roots(info):
            return left, right, info
    return None


def eq_extraneous():
    """Guided 4 / Your Turn 6: x/(x - 3) - 2/(x + 3) = 18/(x^2 - 9): one root is an NPV."""
    for _ in range(60):
        p, q = nz(-6, 6), nz(-6, 6)
        if p == -q:
            continue
        r = nz(-9, 9, avoid=(p, -q))
        bad = random.random() < 0.7
        if bad:                                            # x = p comes out, and it's an NPV
            beta = -(p + r) - q
            k = -beta * p - p * r
        else:
            s = nz(-9, 9, avoid=(p, -q, r))
            beta = -(r + s) - q                            # x^2 + (q + beta)x - beta p - k = 0, roots r, s
            k = -beta * p - r * s
        if beta == 0 or k == 0:
            continue
        left = [(X, Fac(1, [(1, -p)])), (Poly.const(beta), Fac(1, [(1, q)]))]
        right = [(Poly.const(k), Fac(1, [(1, -p), (1, q)]))]
        info = solve_eq(left, right)
        if nice_roots(info):
            return left, right, info
    return None


def eq_whole_x():
    """Your Turn 3: x - 2x/(x - 3) = 2   (the whole x must be multiplied by the LCD too)."""
    for _ in range(60):
        r, s = random.sample([i for i in range(-9, 10) if i], 2)
        divs = [d for d in range(-12, 13) if d and (r * s) % d == 0 and d not in (r, s)]
        if not divs:
            continue
        p = random.choice(divs)
        c = r * s // p
        a = r + s - p - c                                  # x(x - p) - ax = c(x - p)
        if a == 0 or c == 0 or abs(c) > 12:
            continue
        left = [(X, Fac(1)), (Poly({(1,): -a}), Fac(1, [(1, -p)]))]
        right = [(Poly.const(c), Fac(1))]
        info = solve_eq(left, right)
        if nice_roots(info):
            return left, right, info
    return None


def eq_no_solution():
    """Your Turn 5 type: 2x/(x - 2) = 4/(x - 2) + 1  ->  x = 2, an NPV: no solution."""
    a, c, p = nz(-6, 6), nz(-4, 4), nz(-9, 9)
    if a == c:
        return None
    left = [(Poly({(1,): a}), Fac(1, [(1, -p)]))]
    right = [(Poly.const(a * p), Fac(1, [(1, -p)])), (Poly.const(c), Fac(1))]
    return left, right, solve_eq(left, right)


def q55():
    kind = random.choices(["mono", "quad", "cross", "extra", "wholex", "none", "npv"],
                          weights=[16, 18, 16, 20, 12, 8, 10])[0]
    made = {"mono": eq_monomial, "quad": eq_quadratic_mono, "cross": eq_cross, "extra": eq_extraneous,
            "wholex": eq_whole_x, "none": eq_no_solution, "npv": random.choice([eq_cross, eq_extraneous, eq_whole_x])}[kind]()
    if made is None:
        return None
    left, right, info = made
    if not nice_roots(info) or info is None:
        return None
    ex = _eq_text(left, right)
    if kind == "npv":
        R = info["npv"]
        dens = [d for _, d in left + right]
        traps = [npv_opt({-v for v in R}), npv_opt(set(info["sols"] + info["rej"])),     # gave the solutions
                 npv_opt(dens[0].roots()) if dens[0].roots() != R else None,
                 npv_opt(R | {F(0)}) if 0 not in R else npv_opt(R - {F(0)}),
                 npv_opt(set())]
        text = random.choice(["Find the NPVs:  {}", "State the NPVs first:  {}"]).format(ex)
        return pack(text, npv_opt(R), traps)
    sols, rej = info["sols"], info["rej"]
    allr = sols + rej
    traps = []
    if rej:
        traps.append(sol_opt(allr))                                   # forgot to check the NPVs
        if sols:
            traps.append(sol_opt(rej, sols))                          # rejected the wrong one
            traps.append(sol_opt(rej))
        traps.append(sol_opt([-v for v in sols], [-v for v in rej]) if sols else sol_opt([-v for v in rej]))
    else:
        traps.append(sol_opt([], allr))                               # rejected a good answer
        if len(allr) == 2:
            traps.append(sol_opt(allr[:1], allr[1:]))
            traps.append(sol_opt(allr[1:], allr[:1]))
    if info["skip"]:                                                  # forgot to multiply a whole term
        sk = info["skip"]
        traps.insert(0, sol_opt(sk[0] + sk[1]))
    traps.append(sol_opt([-v for v in allr]))                         # sign slip factoring
    if len(allr) == 2:
        traps.append(sol_opt([-allr[0], allr[1]]))
        traps.append(sol_opt([allr[0], -allr[1]]))
    else:
        traps.append(sol_opt([allr[0] + 1]))
        traps.append(sol_opt([allr[0] * 2]) if allr[0] else None)
    if sols:
        traps.append(sol_opt([], []))                                 # "no solution"
    # never a wrong answer with the same solutions as the right one (only the "rejected" note different)
    traps = [t for t in traps if t is not None and t[1][1] != frozenset(sols)]
    text = random.choice(["Solve:  {}", "Solve (check the NPVs):  {}", "Solve:  {}"]).format(ex)
    return pack(text, sol_opt(sols, rej), traps)


def gen_55():
    return q55()


GENERATORS = {1: gen_51, 2: gen_52, 3: gen_53, 4: gen_54, 5: gen_55}
