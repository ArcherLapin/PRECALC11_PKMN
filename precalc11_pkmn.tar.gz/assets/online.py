# ==========================================
# online.py  -  Online Team Battle and Online Class Raid: the rules and the database (no pygame here).
#   battles.py draws their screens.  Everything meets in a free Firebase Realtime Database:
#     tb/clock/<id>          one-time clock sync          tb/rooms/t1 ... t8   Team Battle, one room per topic
#     tb/raid2/r1 ... r8     Class Raid, one room per topic
#   (The Math 9 game uses DB_FOLDER = "tb/math9" in the same database, so the two never mix.)
#
#   Tests for Mr. Chung's computer (the game never runs them):
#     python online.py --check-files          missing sprites / sounds / music
#     python online.py --make-pin 4826        the line that makes 4826 the teacher PIN
#     python online.py --fake                 fast: fake students raid a pretend database
#     python online.py --screens              slow: the REAL raid screens and questions, played by fake students
#         --net good/school/terrible   --students 30   --mode easy/medium/hard   --runs 5
#         --teacher (Magikarp watches)   --leader-drops   --topic 4 (--screens: which room, default 8)
#     python online.py --students 20          fake students on the REAL database (hidden test room r99)
# ==========================================
import hashlib
import json
import os
import random
import sys
import time
from urllib.parse import urlparse

import pokedex

# ==========================================
# 1. TEAM BATTLE: SETTINGS
#   2 students (one room per topic) vs 2 AI Pokemon.  For 2 vs 2 students, make both "ai" "human".
#   Every browser replays the same turn log, so everyone sees the same HP.  A student writes their own
#   turn; the first student still connected writes the AI's turns (and "zoned out" for a closed tab).
# ==========================================
FIREBASE_URL = "https://pkmngame-a5711-default-rtdb.firebaseio.com"
DB_FOLDER = "tb"           # this game's folder in the database (Math 9: "tb/math9")

# The battle, in turn order. Same "team" number = same side.
#   pokemon: a name from pokedex.py     player: "human" (a student) or "ai"
TEAM_SETUP = [
    {"pokemon": "Pikachu",   "team": 0, "player": "human", "hp": 300},
    {"pokemon": "Raichu",    "team": 0, "player": "human", "hp": 300},
    {"pokemon": "Vaporeon",  "team": 1, "player": "ai",    "hp": 350},
    {"pokemon": "Flareon",   "team": 1, "player": "ai",    "hp": 350},
]

RANDOM_TURN_ORDER = True   # True: a new random turn order each battle (not shown to students)
                           # False: always the TEAM_SETUP order

PLAYER_POWER = 30          # damage for a correct answer (before the streak bonus)
STREAK_BONUS = 1.2         # x1.2 more damage for each correct answer in a row
CRIT_CHANCE = 5            # % chance a correct answer is a critical hit (x1.5)
AI_ATTACK = 100            # AI damage = move power x AI_ATTACK / 100 (moves: pokedex.py)
BERRIES = 1                # Sitrus Berries per student (eating one uses your turn)
BERRY_HEAL = 50
TURN_SECONDS = 60          # time limit for a student's turn
TURN_SECONDS_BY_TOPIC = {} # a different limit for some topics, e.g. {8: 90} (8 = Unit 4 Review)

# ---------- Timing (milliseconds) ----------
READ_MS = 8000             # time to read the last turn's messages before a student's clock starts
AI_THINK_MS = 4000         # an AI moves this long after the turn before it
INTRO_MS = 7000            # "Team Battle!" messages before the first turn
GRACE_MS = 4000            # wait past a student's deadline before someone else zones them out
LEFT_MS = 12000            # no heartbeat for this long = the student closed the tab
WAIT_FRESH_MS = 9000       # a waiting student counts if their heartbeat is newer than this
WAIT_PURGE_MS = 60000      # old waiting entries are deleted after this
SV = {".sv": "timestamp"}  # Firebase fills in its own time
REQUEST_TIMEOUT_MS = 8000  # no answer by then = failed (and retried): a stuck request can't freeze anyone

N = len(TEAM_SETUP)
HUMAN_SLOTS = [i for i, s in enumerate(TEAM_SETUP) if s["player"] == "human"]
ROOM_SIZE = len(HUMAN_SLOTS)


def local_ms():
    return time.time() * 1000.0


def slot_name(i):
    return TEAM_SETUP[i]["pokemon"]


def slot_team(i):
    return TEAM_SETUP[i]["team"]


def is_ai(i):
    return TEAM_SETUP[i]["player"] == "ai"


# ==========================================
# 2. TRANSPORTS: how a request is sent
# ==========================================
class JSTransport:
    """In the browser (pygbag): uses the page's own fetch(). Results are picked up each frame."""
    _JS = r"""
window.__tb = window.__tb || {res: {}};
window.tbReq = function (id, method, url, body, ms) {
  var opt = {method: method, cache: "no-store"};
  if (body !== "") { opt.body = body; }
  if (ms && typeof AbortController !== "undefined") {      // give up on a stuck request
    var ctl = new AbortController();
    opt.signal = ctl.signal;
    setTimeout(function () { ctl.abort(); }, ms);
  }
  fetch(url, opt).then(function (r) {
    return r.text().then(function (t) { window.__tb.res[id] = r.status + "\n" + t; });
  }).catch(function (e) { window.__tb.res[id] = "0\n" + e; });
  return 1;
};
window.tbTake = function (id) {
  var v = window.__tb.res[id];
  if (v === undefined) { return ""; }
  delete window.__tb.res[id];
  return v;
};
"""

    def __init__(self):
        import platform as _pf
        self.win = _pf.window
        try:
            self.win.eval(self._JS)
        except Exception:
            self.win.Function(self._JS)()

    def start(self, rid, method, url, body):
        self.win.tbReq(rid, method, url, body, REQUEST_TIMEOUT_MS)

    def take(self, rid):
        v = self.win.tbTake(rid)
        v = "" if v is None else str(v)
        if not v:
            return None
        status, _, text = v.partition("\n")
        try:
            return int(status), text
        except ValueError:
            return 0, text


class ThreadTransport:
    """Running as normal Python on a computer (for testing): urllib in a background thread."""
    def __init__(self):
        import threading
        self.threading = threading
        self.res = {}

    def start(self, rid, method, url, body):
        def work():
            import urllib.request
            import urllib.error
            try:
                req = urllib.request.Request(url, data=body.encode() if body else None, method=method)
                with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_MS / 1000) as r:
                    self.res[rid] = (r.status, r.read().decode())
            except urllib.error.HTTPError as e:
                self.res[rid] = (e.code, e.read().decode(errors="replace"))
            except Exception as e:                       # no internet, bad URL...
                self.res[rid] = (0, str(e))
        self.threading.Thread(target=work, daemon=True).start()

    def take(self, rid):
        return self.res.pop(rid, None)


def make_transport():
    if sys.platform == "emscripten":
        return JSTransport()
    return ThreadTransport()


# ==========================================
# 3. REQUESTS AND THE SERVER CLOCK
# ==========================================
class Call:
    def __init__(self):
        self.done, self.ok, self.status, self.data = False, False, 0, None
        self.t0 = 0                  # when it was sent (Net sets it)


class Net:
    def __init__(self, base_url, transport, now=local_ms):
        self.base = base_url.rstrip("/")
        self.tr = transport
        self.now = now               # this computer's clock (the tests pass a pretend one)
        self.pending = {}
        self.count = 0
        self.errors = 0              # failed requests in a row (for a "connection problem" note)

    def request(self, method, path, body=None):
        self.count += 1
        rid = f"r{self.count}"
        call = Call()
        call.t0 = self.now()
        self.pending[rid] = call
        self.tr.start(rid, method, f"{self.base}/{DB_FOLDER}/{path}.json", "" if body is None else json.dumps(body))
        return call

    def get(self, path):
        return self.request("GET", path)

    def put(self, path, value):
        return self.request("PUT", path, value)

    def delete(self, path):
        return self.request("DELETE", path)

    def update(self):
        for rid in list(self.pending):
            r = self.tr.take(rid)
            if r is None:
                # still no answer well past the time limit (an old browser): count it as failed
                if self.now() - self.pending[rid].t0 > REQUEST_TIMEOUT_MS + 2000:
                    r = (0, "timed out")
                else:
                    continue
            call = self.pending.pop(rid)
            call.status, text = r
            call.ok = 200 <= call.status < 300
            if call.ok:
                try:
                    call.data = json.loads(text) if text else None
                except ValueError:
                    call.ok = False
            call.done = True
            self.errors = 0 if call.ok else self.errors + 1


class Clock:
    """The server's time, estimated from the student's own clock plus an offset."""
    def __init__(self, local=local_ms):
        self.local = local
        self.offset = None

    def ready(self):
        return self.offset is not None

    def now(self):
        return self.local() + (self.offset or 0)


class ClockSync:
    """Write the server time once, read it back, compare with our clock."""
    def __init__(self, net, clock, me):
        self.net, self.clock, self.me = net, clock, me
        self.step, self.call, self.t0, self.t1 = 0, None, 0, 0

    def update(self):
        if self.clock.ready():
            return True
        if self.call is None:
            self.t0 = self.clock.local()
            self.call = self.net.put(f"clock/{self.me}", SV)
            self.step = 1
        elif self.call.done:
            if not self.call.ok:
                self.call = None                           # try again
            elif self.step == 1:
                self.t1 = self.clock.local()
                self.call = self.net.get(f"clock/{self.me}")
                self.step = 2
            else:
                ts = self.call.data
                if isinstance(ts, (int, float)):
                    self.clock.offset = ts - (self.t0 + self.t1) / 2
                    self.net.delete(f"clock/{self.me}")
                    return True
                self.call = None
        return False


def new_id():
    """A player/game id. Includes the time in ms, so two copies can't share one even if
    their random numbers were the same."""
    stamp = int(time.time() * 1000) % (36 ** 6)
    tail = "".join(random.choice("abcdefghjkmnpqrstuvwxyz23456789") for _ in range(8))
    return f"{stamp:x}{tail}"


def room_key(level):
    return f"t{level}"     # (keys that are plain numbers would turn into a list in Firebase)


# ==========================================
# 4. TEAM BATTLE: ROOMS (topic screen and waiting room)
# ==========================================
def fresh_waiting(room, now):
    """Ids of the students really waiting in a room, first to join first."""
    w = (room or {}).get("waiting") or {}
    out = []
    for pid, e in w.items():
        if isinstance(e, dict) and isinstance(e.get("t"), (int, float)) and now - e["t"] <= WAIT_FRESH_MS:
            j = e.get("j") if isinstance(e.get("j"), (int, float)) else e["t"]
            out.append((j, pid))
    out.sort()
    return [pid for _, pid in out]


def game_ok(game):
    return (isinstance(game, dict) and isinstance(game.get("order"), list) and len(game["order"]) == N
            and isinstance(game.get("start"), (int, float)))


def game_active(game, now):
    """A battle is going on: not finished, and a student in it is still connected."""
    if not game_ok(game) or game.get("over"):
        return False
    if now - game["start"] < 30000:
        return True
    alive = game.get("alive") or {}
    return any(isinstance(alive.get(game["order"][i]), (int, float)) and now - alive[game["order"][i]] <= LEFT_MS
               for i in HUMAN_SLOTS)


def room_status(room, now):
    """('busy', 0) for a battle in progress, else ('open', number waiting)."""
    if game_active((room or {}).get("game"), now):
        return "busy", 0
    return "open", len(fresh_waiting(room, now))


class Lobby:
    """Reads all the rooms every 2 seconds.  status = {level: (state, count)}."""
    def __init__(self, net, clock, levels):
        self.net, self.clock, self.levels = net, clock, list(levels)
        self.call, self.next_t = None, 0
        self.status = None

    def update(self):
        t = self.clock.local()
        if self.call is None and t >= self.next_t:
            self.call = self.net.get("rooms")
        elif self.call is not None and self.call.done:
            if self.call.ok:
                rooms = self.call.data if isinstance(self.call.data, dict) else {}
                now = self.clock.now()
                self.status = {lv: room_status(rooms.get(room_key(lv)), now) for lv in self.levels}
            self.call, self.next_t = None, t + 2000


class Waiter:
    """Sitting in a topic's waiting room. result becomes ('start', game) or ('full', None)."""
    def __init__(self, net, clock, level, me):
        self.net, self.clock, self.me, self.level = net, clock, me, level
        self.path = f"rooms/{room_key(level)}"
        self.j = None                            # when I joined (server time), once known
        self.count = 1
        self.result = None
        self.beat, self.next_beat = None, 0
        self.poll, self.next_poll = None, 0
        self.made, self.made_call = None, None   # the game I created, if I am the host
        self.left = False

    def leave(self):
        if not self.left:
            self.left = True
            self.net.delete(f"{self.path}/waiting/{self.me}")

    def update(self):
        if self.result or self.left:
            return
        t = self.clock.local()
        if self.made_call is not None and self.made_call.done:
            if not self.made_call.ok:
                self.made = None                 # could not create the game: try again
            self.made_call = None
        if (self.beat is None or self.beat.done) and t >= self.next_beat:
            self.beat = self.net.put(f"{self.path}/waiting/{self.me}", {"j": self.j if self.j else SV, "t": SV})
            self.next_beat = t + 2000
        if self.poll is None and t >= self.next_poll:
            self.poll = self.net.get(self.path)
        elif self.poll is not None and self.poll.done:
            if self.poll.ok:
                self._look(self.poll.data if isinstance(self.poll.data, dict) else {})
            self.poll, self.next_poll = None, t + 1000

    def _look(self, room):
        now = self.clock.now()
        mine = (room.get("waiting") or {}).get(self.me)
        if self.j is None and isinstance(mine, dict) and isinstance(mine.get("j"), (int, float)):
            self.j = mine["j"]
        game = room.get("game")
        if game_active(game, now):
            if self.me in game["order"]:
                self.result = ("start", game)
            elif self.made is None:
                self.result = ("full", None)
            if self.result:
                self.leave()
            return
        fresh = fresh_waiting(room, now)
        self.count = max(1, len(fresh))
        if fresh and fresh[0] == self.me:        # first in line looks after the room
            for pid, e in (room.get("waiting") or {}).items():
                if not isinstance(e, dict) or now - (e.get("t") or 0) > WAIT_PURGE_MS:
                    self.net.delete(f"{self.path}/waiting/{pid}")
            if len(fresh) >= ROOM_SIZE and self.made is None:
                self.made = make_game(fresh[:ROOM_SIZE], self.level)
                self.made_call = self.net.put(f"{self.path}/game", self.made)


def make_game(players, level):
    """Students go into the human slots at random (so who is Pikachu is random)."""
    ids = list(players)
    random.shuffle(ids)
    order = [ids.pop() if i in HUMAN_SLOTS else f"ai{i}" for i in range(N)]
    turns = random.sample(range(N), N) if RANDOM_TURN_ORDER else list(range(N))
    return {"id": new_id(), "level": level, "start": SV, "order": order, "turns": turns}


def turn_order(game):
    """The battle's turn order (slot numbers); TEAM_SETUP order if missing or broken."""
    t = game.get("turns")
    return list(t) if isinstance(t, list) and sorted(t) == list(range(N)) else list(range(N))


# ==========================================
# 5. TEAM BATTLE: REPLAYING THE TURN LOG
#   Slots are 0..N-1 in TEAM_SETUP order.  A message: (text, target slot or None, HP change, effect or None).
# ==========================================
def teammates(i):
    return [j for j in range(N) if slot_team(j) == slot_team(i)]


def foes(i):
    return [j for j in range(N) if slot_team(j) != slot_team(i)]


def target_for(i, hp):
    """A correct answer hits the opponent in the same position (1st or 2nd); if fainted, another."""
    fs = [j for j in foes(i)]
    first = fs[teammates(i).index(i) % len(fs)]
    if hp[first] > 0:
        return first
    return next((j for j in fs if hp[j] > 0), None)


def log_keys(game):
    log = game.get("log") or {}
    if not isinstance(log, dict):
        return []
    ks = sorted((int(k[1:]), k) for k in log if isinstance(k, str) and k[:1] == "e" and k[1:].isdigit())
    return [k for _, k in ks]


class State:
    pass


def replay(game, my_slot=None):
    """
    Works out the battle from the start, one log entry at a time. Returns a State:
      hp, streak, berries (per slot), active (whose turn, or None), base (when that turn
      started), deadline (for a student's turn), next_key, over, winner (team number),
      entries: (log key, messages) so new entries can be shown.
    """
    s = State()
    s.hp = [TEAM_SETUP[i]["hp"] for i in range(N)]
    s.max_hp = list(s.hp)
    s.streak = [0] * N
    s.berries = [BERRIES] * N
    s.entries, s.over, s.winner = [], False, None
    base = game["start"] + INTRO_MS
    nm = slot_name

    turns = turn_order(game)

    def next_alive(pos):
        """Position in the turn order of the next Pokemon still standing."""
        return next(((pos + k) % N for k in range(N) if s.hp[turns[(pos + k) % N]] > 0), None)

    pos = next_alive(0)
    a = turns[pos]
    keys = log_keys(game)
    log = game.get("log") or {}
    for key in keys:
        ev = log.get(key)
        msgs = []
        if (s.over or not isinstance(ev, dict) or ev.get("g") != game.get("id") or ev.get("p") != a
                or (ev.get("r") == "mv") != is_ai(a) and ev.get("r") != "zo"):
            s.entries.append((key, msgs))             # out-of-date, doubled or wrong-kind entry: ignored
            continue
        p, r = a, ev.get("r")
        if r == "ok":                                  # a student answered correctly
            tgt = ev.get("tg")                         # the opponent they clicked
            if tgt not in foes(p) or s.hp[tgt] <= 0:
                tgt = target_for(p, s.hp)
            d = max(0, min(int(ev.get("d") or 0), 999))
            msgs.append((f"{nm(p)} answered correctly!", None, 0, None))
            if s.streak[p] > 0:
                msgs.append((f"{nm(p)} is pumped! (+{s.streak[p] * 20}%)", None, 0, None))
            msgs.append((f"{nm(p)} used {pokedex.attack_name(nm(p))} on {nm(tgt)}!", None, 0, None))
            msgs.append(("A critical hit! It dealt %d damage!" % d if ev.get("x") else f"It dealt {d} damage!",
                         tgt, -d, pokedex.PLAYER_ATTACK_EFFECT))
            s.hp[tgt] = max(0, s.hp[tgt] - d)
            s.streak[p] += 1
            if s.hp[tgt] == 0:
                msgs.append((f"{nm(tgt)} fainted!", None, 0, None))
        elif r == "mv":                                # an AI's move
            moves = pokedex.moves(nm(p))
            mname, _, _, _, effect = moves[int(ev.get("m") or 0) % len(moves)]
            tgt = ev.get("tg")
            if tgt not in foes(p) or s.hp[tgt] <= 0:
                tgt = target_for(p, s.hp)
            msgs.append((f"{nm(p)} used {mname} on {nm(tgt)}!", None, 0, None))
            if ev.get("ms"):
                msgs.append((f"{nm(p)}'s attack missed!", None, 0, None))
            else:
                d = max(0, min(int(ev.get("d") or 0), 999))
                msgs.append(("A critical hit! It dealt %d damage!" % d if ev.get("x") else f"It dealt {d} damage!",
                             tgt, -d, effect))
                s.hp[tgt] = max(0, s.hp[tgt] - d)
                if s.hp[tgt] == 0:
                    msgs.append((f"{nm(tgt)} fainted!", None, 0, None))
        elif r == "be" and s.berries[p] > 0:          # Sitrus Berry
            s.berries[p] -= 1
            heal = min(BERRY_HEAL, s.max_hp[p] - s.hp[p])
            msgs.append((f"{nm(p)} ate a Sitrus Berry!", None, 0, None))
            msgs.append((f"{nm(p)} recovered {heal} HP!", p, heal, None))
            s.hp[p] += heal
        elif r == "no":                                # wrong answer
            msgs.append((f"{nm(p)} got it wrong!", None, 0, None))
            if p == my_slot and ev.get("c"):
                msgs.append((f"The answer was:  {ev['c']}", None, 0, None))
            if s.streak[p] > 0:
                msgs.append((f"{nm(p)} calms down (0%).", None, 0, None))
            s.streak[p] = 0
        else:                                          # "zo": time ran out
            msgs.append((f"{nm(p)} zoned out!" + ("  (left the battle)" if ev.get("L") else ""), None, 0, None))
            s.streak[p] = 0
        s.entries.append((key, msgs))
        if isinstance(ev.get("t"), (int, float)):
            base = ev["t"]
        for team in {slot_team(j) for j in range(N)}:
            if all(s.hp[j] == 0 for j in range(N) if slot_team(j) == team):
                s.over = True
                s.winner = next(slot_team(j) for j in range(N) if slot_team(j) != team)
        if s.over:
            msgs.append(("The battle is over!", None, 0, None))
        else:
            pos = next_alive(pos + 1)
            a = turns[pos]

    s.active = None if s.over else a
    s.base = base
    s.turn_secs = turn_seconds(game.get("level"))
    s.deadline = base + READ_MS + s.turn_secs * 1000
    last = int(keys[-1][1:]) if keys else -1
    s.next_key = f"e{last + 1:03d}"
    return s


def time_left(state, now):
    """Seconds left on a student's clock (0 .. this topic's time limit)."""
    return max(0, min(state.turn_secs, int((state.deadline - now + 999) // 1000)))


def turn_seconds(level):
    """Time limit for a turn in this topic (TURN_SECONDS_BY_TOPIC, else TURN_SECONDS)."""
    return TURN_SECONDS_BY_TOPIC.get(level, TURN_SECONDS)


def ai_move(i, hp):
    """An AI picks one of its moves and a student to hit (rolled once, then saved in the log)."""
    moves = pokedex.moves(slot_name(i))
    m = random.randrange(len(moves))
    _, power, miss, crit, _ = moves[m]
    targets = [j for j in foes(i) if hp[j] > 0]
    ev = {"m": m, "tg": random.choice(targets) if targets else None}
    damage = int(power * AI_ATTACK / 100)
    if random.randint(1, 100) <= miss:
        ev["ms"] = True
    elif random.randint(1, 100) <= crit:
        ev["d"], ev["x"] = int(damage * 1.5), True
    else:
        ev["d"] = damage
    return ev


# ==========================================
# 6. TEAM BATTLE: ONE STUDENT'S SIDE
# ==========================================
class Battle:
    """Keeps this browser in step with the battle. The screen reads .state and new messages."""
    def __init__(self, net, clock, level, me, game):
        self.net, self.clock, self.me = net, clock, me
        self.path = f"rooms/{room_key(level)}/game"
        self.game = game
        self.gid = game.get("id")
        self.slot = game["order"].index(me)
        self.state = replay(game, self.slot)
        self.shown = set()                     # log keys already shown as messages
        self.poll, self.next_poll = None, 0
        self.beat, self.next_beat = None, 0
        self.written = set()                   # log keys this browser has written
        self.sending = {}                      # log key -> (entry, request), until it arrives
        self.over_call = None
        self.gone = False                      # the game was replaced or deleted

    # ----- what the screen calls -----
    def my_turn(self):
        return self.state.active == self.slot and self.state.next_key not in self.written

    def send(self, result, damage=0, crit=False, correct_text="", target=None):
        """result: 'ok' (correct; target = the opponent's slot), 'no' (wrong), 'be' (berry)."""
        if not self.my_turn():
            return False
        self._write(self.slot, result, d=damage, x=crit, c=correct_text, tg=target)
        return True

    def damage_now(self):
        """Damage my correct answer does right now, and whether it's a critical hit."""
        power = round(PLAYER_POWER * STREAK_BONUS ** self.state.streak[self.slot])
        crit = random.randint(1, 100) <= CRIT_CHANCE
        return (int(power * 1.5) if crit else power), crit

    def new_messages(self):
        out = []
        for key, msgs in self.state.entries:
            if key not in self.shown:
                self.shown.add(key)
                out += msgs
        return out

    def skip_old(self):
        """Joining part-way: don't replay the whole battle as messages."""
        for key, _ in self.state.entries:
            self.shown.add(key)

    # ----- internals -----
    def _write(self, slot, result, **extra):
        key = self.state.next_key
        ev = {"g": self.gid, "p": slot, "r": result, "t": SV}
        ev.update({k: v for k, v in extra.items() if v or v == 0 and k == "tg"})
        self.written.add(key)
        self.sending[key] = (ev, self.net.put(f"{self.path}/log/{key}", ev))

    def _resend(self):
        """A turn that failed to send is sent again (the same entry, never a new roll)."""
        for key, (ev, call) in list(self.sending.items()):
            if not call.done:
                continue
            if call.ok or key != self.state.next_key:
                del self.sending[key]
            else:
                self.sending[key] = (ev, self.net.put(f"{self.path}/log/{key}", ev))

    def _alive(self, pid, now):
        a = (self.game.get("alive") or {}).get(pid)
        return isinstance(a, (int, float)) and now - a <= LEFT_MS

    def update(self):
        if self.gone:
            return
        t = self.clock.local()
        if not self.state.over and (self.beat is None or self.beat.done) and t >= self.next_beat:
            self.beat = self.net.put(f"{self.path}/alive/{self.me}", SV)
            self.next_beat = t + 2000
        if self.poll is None and t >= self.next_poll:
            self.poll = self.net.get(self.path)
        elif self.poll is not None and self.poll.done:
            if self.poll.ok:
                g = self.poll.data
                if game_ok(g) and g.get("id") == self.gid:
                    self.game = g
                    self.state = replay(g, self.slot)
                elif not self.state.over:
                    self.gone = True
            self.poll, self.next_poll = None, t + 1000
        self._resend()
        self._timers()

    def _timers(self):
        s, now, order = self.state, self.clock.now(), self.game["order"]
        if s.over:
            c = self.over_call
            if c is None or (c.done and not c.ok):
                self.over_call = self.net.put(f"{self.path}/over", True)
            return
        if s.active is None or s.next_key in self.written:
            return
        if s.active == self.slot:                              # my turn: my own clock
            if now >= s.deadline:
                self._write(self.slot, "zo")
            return
        # someone else's turn: the first other student still connected plays the AI / covers a closed tab
        keeper = next((i for i in HUMAN_SLOTS
                       if i != s.active and (order[i] == self.me or self._alive(order[i], now))), None)
        if keeper != self.slot:
            return
        if is_ai(s.active):
            if now >= s.base + AI_THINK_MS:
                ev = ai_move(s.active, s.hp)
                self._write(s.active, "mv", **ev)
        elif now >= s.deadline + GRACE_MS:
            self._write(s.active, "zo")
        elif (not self._alive(order[s.active], now) and now >= s.base + 3000
              and now - self.game["start"] > 15000):
            self._write(s.active, "zo", L=True)


# ==========================================
# 7. CLASS RAID: SETTINGS
#   Everyone in a room fights the same Mewtwo, each in their own 1-on-1 fight: answer -> your attack
#   (if right) -> Mewtwo's turn (an attack, or Recover after a wrong answer).  Each student writes only
#   their OWN totals, so Mewtwo's HP = full HP - everyone's damage + everyone's Recover, worked out the
#   same way on every screen.  The class loses when time runs out or everyone is fainted at once.
#   The first one in the room leads (difficulty + Start); if they're gone LEADER_SECONDS, the next one does.
#   Safe on slow Wi-Fi: Start only ever ADDS a raid (the earliest one wins, extras close themselves),
#   an out-of-date screen makes no decisions, and "reset" needs the raid missing from several reads.
#   Database, tb/raid2/r<topic>:
#     who/<id>/j, t, m        joined (written once), heartbeat, Pokemon
#     raids/<id>              {id, start, mode, by, over: "" / win / lose / left / dup}
#       p/<id>                {m, d: damage, h: Recover HP, a: answers, f: fainted, t: heartbeat}
#       pj/<id>               joined this raid (orders "Pikachu #1", "Pikachu #2")
# ==========================================
BOSS = "Mewtwo"                # the boss (pokedex.py)
OBSERVER = "Magikarp"          # Mr. Chung's Pokemon (teacher PIN): watches, never ranked or counted
RAID_POOL = []                 # who students can pick, e.g. ["Pikachu", "Eevee"]; [] = every pokedex.py
                               # entry with an "attack" (not Mewtwo or Magikarp)
MAX_TILES = 30                 # the pick screen shows at most this many
RAID_MINUTES = 30              # time limit
RAID_PLAYER_HP = 300           # every student's Pokemon (damage, streak and crits: Team Battle's numbers)
STREAK_CAP = 2.0               # the streak bonus stops at x2
NO_DAMAGE = {OBSERVER}
RECOVER_HP = 30                # Mewtwo's Recover
REVIVE_STEP = 20               # fainted: each right answer = 20% more HP when you get up...
REVIVE_FULL = 5                # ...and 5 right = back up at 100% by itself
REST_SECONDS = 60              # fainted + first answer wrong: wait this long
RAID_BERRIES = 2               # Sitrus Berries per student (also the most you can hold)
RAID_BERRY_HEAL = 100          # eating one uses your turn.  Getting up gives +1 (under 50% HP) or +2.
TOP_N = 10                     # the ranking at the end

# Teacher PIN: only a fingerprint is stored.  New PIN: python online.py --make-pin 4826
TEACHER_PIN_HASH = "10235b9b3f6b4badbfb8e299061a4daf1d24e78b149dbb29422af98ff6d4d49a"

RAID_BACKGROUND = "background.jpg"
RAID_MUSIC = ["music10.ogg", "music11.ogg", "music12.ogg"]    # played RAID_MUSIC_CHANCE % of the time,
RAID_MUSIC_CHANCE = 80
OTHER_MUSIC = [f"music{n}.ogg" for n in range(1, 10)]         # otherwise one of these

# Difficulty (the leader picks one).  hp_per_player: Mewtwo's HP per student who has answered;
# power: x Mewtwo's move power (pokedex.py); recover: % chance of Recover after a wrong answer.
# Tuned (python online.py --fake) for 20-50 s per question: a class about 60% / 70% / 80% right
# wins in about 24 minutes; 10 points lower usually runs out of time.
MODES = {
    "easy":   {"name": "Easy",   "hp_per_player": 620, "power": 0.6,  "recover": 10},
    "medium": {"name": "Medium", "hp_per_player": 650, "power": 0.9,  "recover": 20},
    "hard":   {"name": "Hard",   "hp_per_player": 760, "power": 1.15, "recover": 30},
}
MODE_ORDER = ["easy", "medium", "hard"]
DEFAULT_MODE = "medium"

# ---------- Timing (milliseconds) ----------
POLL_MS = 1000                 # read the room this often in the lobby...
RAID_POLL_MS = 2000            # ...and during a raid
BACKUP_POLL_MS = 2500          # a read unanswered this long: send a second one (first answer wins)
BEAT_MS = 3000                 # "I'm still here"
FRESH_MS = 12000               # no heartbeat this long = not "in the room" / "in battle"
LEADER_SECONDS = 30            # the leader keeps the job through a short tab switch or Wi-Fi hiccup
STALE_MS = 5000                # my last good read is older: I make no decisions (start, close, wipe)
SLOW_NOTE_MS = 8000            # ...older still: "Slow connection: reconnecting..."
ABANDON_MS = 90000             # nobody in a raid this long (Magikarp counts) = closed
GONE_READS = 3                 # my raid missing from this many good reads in a row = "reset"
WIPE_MS = 4000                 # "everyone fainted" must hold this long
START_LOCK_MS = 10000          # "Starting..." after Start (no second raid)
PURGE_MS = 60000               # silent this long = removed from the room list
KEEP_ENDED_MS = 5 * 60000      # a finished raid is kept this long (for late rankings)
LEADER_MS = LEADER_SECONDS * 1000
RAID_MS = RAID_MINUTES * 60 * 1000
REST_MS = REST_SECONDS * 1000
RAID_ROOT = "raid2"

def mode_info(mode):
    return MODES.get(mode, MODES[DEFAULT_MODE])


def pool():
    """The Pokemon students can pick (folder order); a new pokedex.py entry shows up by itself."""
    if RAID_POOL:
        names = [n for n in RAID_POOL if n in pokedex.POKEMON and n not in (BOSS, OBSERVER)]
    else:
        names = [n for n, e in pokedex.POKEMON.items()
                 if n not in (BOSS, OBSERVER) and e.get("folder") is not None and "attack" in e]
        names.sort(key=lambda n: pokedex.POKEMON[n]["folder"])
    return names[:MAX_TILES]


def roster():
    """Every Pokemon the raid can show (for --check-files)."""
    return pool() + [OBSERVER]


def attack_of(mon):
    """(move name, effect) a student's Pokemon uses on a correct answer."""
    return pokedex.attack_name(mon), pokedex.info(mon).get("attack_effect", pokedex.PLAYER_ATTACK_EFFECT)


def pin_hash(pin):
    return hashlib.sha256(("pokemon-raid-pin:" + str(pin).strip()).encode()).hexdigest()


def check_pin(pin):
    return pin_hash(pin) == TEACHER_PIN_HASH


# ==========================================
# 8. CLASS RAID: ONE STUDENT'S FIGHT  (used by the screen and by the tests' fake students)
#   Returns messages (text, kind, amount, effect); kind: None, "boss_hit", "boss_heal", "boss_faint",
#   "me_hit", "me_heal" (amount = HP after healing), "faint".
# ==========================================
class Fighter:
    def __init__(self, mon, mode):
        self.mon, self.mode = mon, mode_info(mode)
        self.max_hp = self.hp = RAID_PLAYER_HP
        self.streak = 0
        self.fainted, self.revive, self.rest_until = False, 0, 0
        self.d = self.h = 0                      # damage dealt, HP Mewtwo recovered (after my wrong answers)
        self.answered = self.correct = self.wrong = 0
        self.berries = RAID_BERRIES

    def resting(self, now):
        return self.fainted and now < self.rest_until

    def can_get_up(self):
        return self.fainted and self.revive > 0

    def answer(self, ok, boss_hp, boss_max, now):
        """ok = answered correctly.  boss_hp / boss_max: Mewtwo right now (for Recover and the win)."""
        self.answered += 1
        if ok:
            self.correct += 1
        else:
            self.wrong += 1
        if self.fainted:
            return self._revive_answer(ok, now)
        out = []
        nm = self.mon
        if ok:
            move, effect = attack_of(nm)
            if nm in NO_DAMAGE:
                out += [(f"{nm} used {move}!", None, 0, None), ("But nothing happened!", None, 0, None)]
            else:
                mult = min(STREAK_BONUS ** self.streak, STREAK_CAP)
                if self.streak:
                    out.append((f"{nm} is pumped! (+{round((mult - 1) * 100)}%)", None, 0, None))
                power = round(PLAYER_POWER * mult)
                crit = random.randint(1, 100) <= CRIT_CHANCE
                dmg = int(power * 1.5) if crit else power
                out.append((f"{nm} used {move}!", None, 0, None))
                out.append((("A critical hit! " if crit else "") + f"It dealt {dmg} damage!", "boss_hit", dmg, effect))
                self.d += dmg
                boss_hp -= dmg
            self.streak += 1
            if boss_hp <= 0:
                out.append((f"{BOSS} fainted!", "boss_faint", 0, None))
                return out
        else:
            if self.streak:
                out.append((f"{nm} calms down (0%).", None, 0, None))
            self.streak = 0
        # Mewtwo's turn: after a wrong answer it sometimes uses Recover instead of attacking
        if not ok and boss_hp < boss_max and random.randint(1, 100) <= self.mode["recover"]:
            heal = min(RECOVER_HP, boss_max - boss_hp)
            self.h += heal
            out += [(f"{BOSS} used Recover!", None, 0, None),
                    (f"{BOSS} recovered {heal} HP!", "boss_heal", heal, None)]
            return out
        return out + self._boss_attack()

    def _boss_attack(self):
        mname, power, miss, crit, effect = random.choice(pokedex.moves(BOSS))
        out = [(f"{BOSS} used {mname}!", None, 0, None)]
        if random.randint(1, 100) <= miss:
            return out + [(f"{BOSS}'s attack missed!", None, 0, None)]
        dmg = int(power * self.mode["power"])
        text = f"It dealt {dmg} damage!"
        if random.randint(1, 100) <= crit:
            dmg = int(dmg * 1.5)
            text = f"A critical hit! It dealt {dmg} damage!"
        self.hp = max(0, self.hp - dmg)
        out.append((text, "me_hit", dmg, effect))
        if self.hp == 0:
            self.fainted, self.revive, self.streak = True, 0, 0
            out.append((f"{self.mon} fainted!", "faint", 0, None))
        return out

    def _revive_answer(self, ok, now):
        if ok:
            self.revive += 1
            if self.revive >= REVIVE_FULL:
                return self.get_up()
            return [(f"Recovery: {self.revive * REVIVE_STEP}%", None, 0, None)]
        if self.revive == 0:
            self.rest_until = now + REST_MS
            return [("Catch your breath: a new question in 1 minute.", None, 0, None)]
        return [("That one was wrong, so up you get!", None, 0, None)] + self.get_up()

    def eat_berry(self):
        """A Sitrus Berry: back up to RAID_BERRY_HEAL HP, then Mewtwo's turn (like the other modes).
        Not while fainted, with none left, or at full HP (the screen says so instead)."""
        if self.fainted or self.berries <= 0 or self.hp >= self.max_hp:
            return []
        self.berries -= 1
        heal = min(RAID_BERRY_HEAL, self.max_hp - self.hp)
        self.hp += heal
        out = [(f"{self.mon} ate a Sitrus Berry!", None, 0, None),
               (f"{self.mon} recovered {heal} HP!", "me_heal", self.hp, None)]
        return out + self._boss_attack()

    def get_up(self):
        """Get up now with 20% x correct answers (the button, a wrong answer, or 5 right)."""
        if not self.can_get_up():
            return []
        pct = min(100, self.revive * REVIVE_STEP)
        self.hp = max(1, self.max_hp * pct // 100)
        self.fainted, self.revive, self.streak, self.rest_until = False, 0, 0, 0
        out = [(f"{self.mon} got back up with {self.hp} HP!", "me_heal", self.hp, None)]
        found = min(1 if pct < 50 else 2, RAID_BERRIES - self.berries)      # never more than RAID_BERRIES
        if found > 0:
            self.berries += found
            out.append((f"{self.mon} found {'a Sitrus Berry' if found == 1 else '2 Sitrus Berries'}!", None, 0, None))
        return out


# ==========================================
# 9. CLASS RAID: READING A ROOM  (every screen gets the same answer from the same data)
# ==========================================
def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def fresh_who(room, now, ms=FRESH_MS):
    """{id: entry} of everyone in the room (lobby or raid) with a heartbeat in the last ms."""
    w = (room or {}).get("who") or {}
    return {pid: e for pid, e in w.items()
            if isinstance(e, dict) and _num(e.get("t")) and now - e["t"] <= ms}


def leader(room, now):
    """The first person to join who is still here (gone less than LEADER_SECONDS).
    Join times are written once, so every screen agrees and the first person stays first."""
    w = {pid: e for pid, e in fresh_who(room, now, LEADER_MS).items() if _num(e.get("j"))}
    if not w:
        return None
    return min(w, key=lambda pid: (w[pid]["j"], pid))


def raid_ok(raid):
    return isinstance(raid, dict) and isinstance(raid.get("id"), str) and _num(raid.get("start"))


def raids_of(room):
    """Every complete raid record in the room."""
    rs = (room or {}).get("raids") or {}
    if not isinstance(rs, dict):
        return []
    return [r for k, r in rs.items() if raid_ok(r) and r["id"] == k]


def players(raid):
    """{id: entry} of everyone who joined this raid."""
    p = (raid or {}).get("p") or {}
    if not isinstance(p, dict):
        return {}
    return {pid: e for pid, e in p.items() if isinstance(e, dict) and isinstance(e.get("m"), str)}


def last_activity(raid):
    """The newest heartbeat in this raid (or its start)."""
    ts = [raid["start"]] + [e["t"] for e in players(raid).values() if _num(e.get("t"))]
    return max(ts)


def raid_ended(raid, now):
    """Won, lost, closed, out of time, or nobody in it for ABANDON_MS."""
    if raid.get("over"):
        return True
    if now > raid["start"] + RAID_MS + 15000:
        return True
    return now - last_activity(raid) > ABANDON_MS


def current_raid(room, now):
    """The raid going on: the EARLIEST-started raid that hasn't ended.  Every screen picks the
    same one (a second Start only adds a later raid, which never wins), so nobody is reset."""
    live = [r for r in raids_of(room) if not raid_ended(r, now)]
    return min(live, key=lambda r: (r["start"], r["id"])) if live else None


def _with_mine(raid, me, mine):
    ps = dict(players(raid))
    if me is not None and mine is not None:
        ps[me] = mine
    return ps


def boss_numbers(raid, me=None, mine=None):
    """(Mewtwo's HP now, full HP).  mine = my own up-to-date entry (the server copy may lag a second).
    Full HP counts each STUDENT who has answered at least once (Magikarp never counts)."""
    ps = _with_mine(raid, me, mine)
    counted = [pid for pid, e in ps.items() if (e.get("a") or 0) > 0 and e["m"] not in NO_DAMAGE]
    full = mode_info(raid.get("mode"))["hp_per_player"] * max(1, len(counted))
    dmg = sum(int(e.get("d") or 0) for e in ps.values())
    heal = sum(int(e.get("h") or 0) for e in ps.values())
    return max(0, min(full, full - dmg + heal)), full


def labels(raid, me=None, mine=None):
    """{id: "Pikachu"} or, when two or more students have the same Pokemon, "Pikachu #1", "Pikachu #2"
    (in the order they joined the raid, so a student's number never changes)."""
    ps = _with_mine(raid, me, mine)
    pj = (raid or {}).get("pj") or {}
    pj = pj if isinstance(pj, dict) else {}
    groups = {}
    for pid, e in ps.items():
        groups.setdefault(e["m"], []).append(pid)
    out = {}
    for mon, ids in groups.items():
        ids.sort(key=lambda pid: (pj.get(pid) if _num(pj.get(pid)) else float("inf"), pid))
        for i, pid in enumerate(ids):
            out[pid] = mon if len(ids) == 1 else f"{mon} #{i + 1}"
    return out


def ranking(raid, me=None, mine=None, n=TOP_N):
    """[(label, id)], best first, by net damage (damage - Recover after their wrong answers).  Top n."""
    ps = _with_mine(raid, me, mine)
    names = labels(raid, me, mine)
    net = {pid: int(e.get("d") or 0) - int(e.get("h") or 0) for pid, e in ps.items()
           if e["m"] not in NO_DAMAGE and (e.get("a") or 0)}
    order = sorted(net, key=lambda pid: (-net[pid], names[pid], pid))
    return [(names[pid], pid) for pid in order[:n]]


def all_fainted(raid, now, me=None, mine=None):
    """True if everyone in the raid right now (who has answered at least once, Magikarp not counted)
    is fainted.  The screen only acts on this with a fresh read, after it holds for WIPE_MS."""
    team = [e for e in _with_mine(raid, me, mine).values()
            if (e.get("a") or 0) > 0 and e["m"] not in NO_DAMAGE and _num(e.get("t")) and now - e["t"] <= FRESH_MS]
    return bool(team) and all(e.get("f") for e in team)


def team_counts(raid, now, me=None, mine=None):
    """(in battle, fainted): students connected right now (a closed tab drops out; Magikarp not counted)."""
    fighting = fainted = 0
    for e in _with_mine(raid, me, mine).values():
        if e["m"] in NO_DAMAGE or not (_num(e.get("t")) and now - e["t"] <= FRESH_MS):
            continue
        if e.get("f"):
            fainted += 1
        else:
            fighting += 1
    return fighting, fainted


def time_left_ms(raid, now):
    return max(0, raid["start"] + RAID_MS - now)


def raid_room_key(k):
    return f"r{k}"


# ==========================================
# 10. CLASS RAID: ONE ROOM ONLINE (lobby + raid)
# ==========================================
class _Field:
    """One value kept on the server: sent until it arrives, sent again only if it changes
    (or if a good read shows it went missing)."""
    _NONE = object()

    def __init__(self, path):
        self.path = path
        self.want, self.have, self.call, self.val, self.ok_at = None, self._NONE, None, None, None

    def set(self, value):
        self.want = value

    def lost(self, read_sent_at):
        """A read sent after this value arrived doesn't have it: send it again."""
        if self.call is None and self.ok_at is not None and read_sent_at > self.ok_at:
            self.have, self.ok_at = self._NONE, None

    def update(self, net, now_local):
        c = self.call
        if c is not None:
            if not c.done:
                return
            if c.ok:
                self.have, self.ok_at = self.val, now_local
            self.call = None
        if self.want is not None and self.want != self.have:
            self.val = self.want
            self.call = net.put(self.path, self.want)


class Room:
    """Being in one raid room: my Pokemon, the lobby, and my totals during a raid."""
    def __init__(self, net, clock, k, me, observer=False):
        self.net, self.clock, self.me = net, clock, me
        self.path = f"{RAID_ROOT}/{raid_room_key(k)}"
        self.observer = observer
        self.data = {}                       # the room as last read
        self.loaded = False
        self.read_at = None                  # (my clock) when the last good read was SENT
        self.mon = OBSERVER if observer else ""
        self.j = _Field(f"{self.path}/who/{me}/j")
        self.j.set(SV)                       # my join time: written once
        self.m = _Field(f"{self.path}/who/{me}/m")
        self.beat, self.next_beat = None, 0
        self.polls, self.poll_sent, self.next_poll = [], 0, 0    # reads on their way: [(request, sent at)]
        # my raid
        self.gid, self.pj = None, None
        self.p_call, self.p_entry, self.p_dirty, self.p_next = None, None, False, 0
        self.missing = 0                     # good reads in a row without my raid in them
        self.start_at = None                 # (my clock) when I pressed Start
        self.left = False

    # ----- what the screens ask -----
    def fresh(self):
        """My copy of the room is recent enough to make decisions with."""
        return self.read_at is not None and self.clock.local() - self.read_at <= STALE_MS

    def slow(self):
        """No fresh news for a while: the screen says "Slow connection"."""
        return self.read_at is not None and self.clock.local() - self.read_at > SLOW_NOTE_MS

    def pick(self, mon):
        if not self.observer:
            self.mon = mon

    def my_pick(self):
        return self.mon or None

    def leave(self):
        if not self.left:
            self.left = True
            self.net.delete(f"{self.path}/who/{self.me}")

    def who(self):
        return fresh_who(self.data, self.clock.now())

    def is_leader(self):
        return self.fresh() and leader(self.data, self.clock.now()) == self.me

    def leader_mon(self):
        lid = leader(self.data, self.clock.now())
        return ((self.data.get("who") or {}).get(lid) or {}).get("m") or ""

    def game(self):
        """The raid going on in this room, or None."""
        return current_raid(self.data, self.clock.now())

    def game_by_id(self, gid):
        rs = self.data.get("raids") or {}
        g = rs.get(gid) if isinstance(rs, dict) else None
        return g if raid_ok(g) and g["id"] == gid else None

    def gone(self, gid):
        """My raid really isn't in the database any more (missing from several good reads)."""
        return gid == self.gid and self.missing >= GONE_READS

    def starting(self):
        """Start was pressed a moment ago and the raid hasn't shown up yet."""
        return (self.start_at is not None and self.clock.local() - self.start_at < START_LOCK_MS
                and self.game() is None)

    def start(self, mode):
        """The leader starts a raid.  Adds a NEW raid; never replaces one."""
        if self.starting() or self.game() is not None or not self.is_leader() or not self.mon:
            return False
        gid = new_id()
        self.net.put(f"{self.path}/raids/{gid}", {"id": gid, "start": SV, "mode": mode, "by": self.me, "over": ""})
        self.start_at = self.clock.local()
        self.next_poll = 0
        return True

    def end(self, gid, result):
        """Mark a raid won / lost / closed (anyone may; the first one to arrive stays)."""
        g = self.game_by_id(gid)
        if g is not None and not g.get("over"):
            self.net.put(f"{self.path}/raids/{gid}/over", result)

    # ----- my totals during a raid -----
    def join(self, gid):
        """I'm in this raid now (my totals and my join time go to it)."""
        if gid != self.gid:
            self.gid, self.missing = gid, 0
            self.pj = _Field(f"{self.path}/raids/{gid}/pj/{self.me}")
            self.pj.set(SV)
            self.p_entry, self.p_call = None, None

    def send(self, gid, fighter):
        """My up-to-date totals (sent right away, then with every heartbeat)."""
        self.join(gid)
        self.p_entry = {"m": fighter.mon, "d": fighter.d, "h": fighter.h, "a": fighter.answered,
                        "f": 1 if fighter.fainted else 0}
        self.p_dirty = True

    def mine(self):
        """My entry as the room should see it (before the server copy catches up)."""
        if self.p_entry is None:
            return None
        return dict(self.p_entry, t=self.clock.now())

    # ----- every frame -----
    def update(self):
        if self.left:
            return
        t = self.clock.local()
        self.j.update(self.net, t)
        self.m.set(self.mon or None)
        self.m.update(self.net, t)
        if (self.beat is None or self.beat.done) and t >= self.next_beat:
            self.beat = self.net.put(f"{self.path}/who/{self.me}/t", SV)
            self.next_beat = t + BEAT_MS
        if self.gid is not None:
            self.pj.update(self.net, t)
            if self.p_call is not None and self.p_call.done:
                if not self.p_call.ok:
                    self.p_dirty = True              # didn't arrive: send the same totals again now
                self.p_call = None
            if self.p_entry is not None and self.p_call is None and (self.p_dirty or t >= self.p_next):
                self.p_call = self.net.put(f"{self.path}/raids/{self.gid}/p/{self.me}", dict(self.p_entry, t=SV))
                self.p_dirty, self.p_next = False, t + BEAT_MS
        # reading the room: one read at a time, plus a backup read if one is slow (newest wins)
        for call, sent in list(self.polls):
            if not call.done:
                continue
            self.polls.remove((call, sent))
            if call.ok and (self.read_at is None or sent > self.read_at):    # never go back to older news
                self.data = call.data if isinstance(call.data, dict) else {}
                self.loaded, self.read_at, self.poll_sent = True, sent, sent
                self._look()
            if not self.polls:
                self.next_poll = t + (RAID_POLL_MS if self.gid else POLL_MS)
        if not self.polls and t >= self.next_poll:
            self.polls.append((self.net.get(self.path), t))
        elif len(self.polls) == 1 and t - self.polls[0][1] >= BACKUP_POLL_MS:
            self.polls.append((self.net.get(self.path), t))

    def _look(self):
        """After every good read: notice anything of mine that went missing, and tidy up (leader)."""
        now = self.clock.now()
        mine = (self.data.get("who") or {}).get(self.me)
        mine = mine if isinstance(mine, dict) else {}
        if not _num(mine.get("j")):
            self.j.lost(self.poll_sent)
        if self.mon and mine.get("m") != self.mon:
            self.m.lost(self.poll_sent)
        if self.gid is not None:
            g = self.game_by_id(self.gid)
            self.missing = 0 if g is not None else self.missing + 1
            if g is not None and not _num(((g.get("pj") or {}) if isinstance(g.get("pj"), dict) else {}).get(self.me)):
                self.pj.lost(self.poll_sent)
        if leader(self.data, now) == self.me:
            self._tidy(now)

    def _tidy(self, now):
        """The leader (with a fresh read) closes leftover raids and removes old entries."""
        for pid, e in (self.data.get("who") or {}).items():
            if not isinstance(e, dict) or not _num(e.get("t")) or now - e["t"] > PURGE_MS:
                self.net.delete(f"{self.path}/who/{pid}")
        rs = self.data.get("raids") or {}
        if not isinstance(rs, dict):
            return
        cur = current_raid(self.data, now)
        for key, r in rs.items():
            if not raid_ok(r) or r["id"] != key:
                if not (isinstance(r, dict) and _num(r.get("start"))):
                    self.net.delete(f"{self.path}/raids/{key}")        # a scrap (e.g. a late write)
                continue
            if not r.get("over"):
                if raid_ended(r, now):                                     # closed for good:
                    out = "lose" if now > r["start"] + RAID_MS else "left"  # out of time / everyone left
                    self.net.put(f"{self.path}/raids/{key}/over", out)
                elif cur is not None and r is not cur:
                    self.net.put(f"{self.path}/raids/{key}/over", "dup")    # a second Start: closed
            elif now - last_activity(r) > KEEP_ENDED_MS:
                self.net.delete(f"{self.path}/raids/{key}")


def _mean(values):
    """Average (the tests only).  Not statistics.mean: pygbag's Python has no statistics
    module and would download a broken one from the internet."""
    values = list(values)
    return sum(values) / len(values) if values else 0


# ==========================================
# 11. TESTS: SETTINGS  (Mr. Chung's computer only; the game never runs sections 11-15)
# ==========================================
STUDENT_SECONDS = (15, 45)       # time a fake student takes per question
STUDENT_ACCURACY = (0.55, 0.85)  # fraction right, per fake student
MSG_SECONDS = 1.5                # each battle message (battles.py MSG_MS)
TEST_ROOM = 99                   # raid2/r99: not one of the topic rooms
TICK_MS = 100

# Wi-Fi: normal time per request (ms), and chances (%) of a slow spike, of failing, of never answering.
NETS = {
    "good":     dict(ms=(60, 200),  slow=0,  spike=(0, 0),        fail=0,  hang=0),
    "school":   dict(ms=(150, 900), slow=8,  spike=(2000, 9000),  fail=4,  hang=2),
    "terrible": dict(ms=(300, 2500), slow=15, spike=(3000, 15000), fail=10, hang=5),
}
TAB_SWITCH = dict(chance_per_min=10, seconds=(5, 75))   # % per minute that a student switches tabs


# ==========================================
# 12. TESTS: A PRETEND FIREBASE  (answers like the real one; requests arrive late, out of order, or never)
# ==========================================
class FakeDB:
    def __init__(self, now, net="good"):
        self.root, self.now, self.cfg = {}, now, NETS[net]
        self.inbox = []                     # (arrival time, request id, transport, method, url, body)
        self.raids_seen = set()

    def _resolve(self, v):
        if isinstance(v, dict):
            if v == {".sv": "timestamp"}:
                return int(self.now())
            return {k: self._resolve(x) for k, x in v.items()}
        return v

    def _parts(self, url):
        p = urlparse(url).path
        p = p[:-5] if p.endswith(".json") else p
        return [s for s in p.split("/") if s]

    def get(self, parts):
        node = self.root
        for k in parts:
            if not isinstance(node, dict) or k not in node:
                return None
            node = node[k]
        return node

    def put(self, parts, value):
        value = self._resolve(value)
        if value in (None, {}):
            self._delete(self.root, parts)
            return None
        node = self.root
        for k in parts[:-1]:
            if not isinstance(node.get(k), dict):
                node[k] = {}
            node = node[k]
        node[parts[-1]] = value
        return value

    def _delete(self, node, parts):
        if not isinstance(node, dict) or not parts:
            return
        k = parts[0]
        if len(parts) == 1:
            node.pop(k, None)
        elif k in node:
            self._delete(node[k], parts[1:])
            if node[k] in ({}, None):
                node.pop(k)

    def handle(self, method, url, body):
        parts = self._parts(url)
        if method == "GET":
            out = self.get(parts)
        elif method == "PUT":
            out = self.put(parts, json.loads(body) if body else None)
            if len(parts) >= 2 and parts[-2] == "raids":
                self.raids_seen.add(parts[-1])
        elif method == "DELETE":
            self._delete(self.root, parts)
            out = None
        else:
            raise ValueError(method)
        return 200, json.dumps(out)

    def delay(self):
        c = self.cfg
        d = random.uniform(*c["ms"]) / 2
        if random.uniform(0, 100) < c["slow"]:
            d += random.uniform(*c["spike"]) / 2
        return d

    def send(self, tr, rid, method, url, body):
        c = self.cfg
        if random.uniform(0, 100) < c["hang"]:
            return                                          # never answers (the game's time limit catches it)
        if random.uniform(0, 100) < c["fail"] / 2:
            tr.res[rid] = (self.now() + self.delay() * 2, 0, "lost")      # lost on the way there
            return
        self.inbox.append((self.now() + self.delay(), rid, tr, method, url, body))

    def tick(self):
        """Requests that reached the server by now are carried out (in arrival order)."""
        now = self.now()
        due = sorted((x for x in self.inbox if x[0] <= now), key=lambda x: x[0])
        if not due:
            return
        self.inbox = [x for x in self.inbox if x[0] > now]
        for _, rid, tr, method, url, body in due:
            status, text = self.handle(method, url, body)
            if random.uniform(0, 100) < self.cfg["fail"] / 2:
                status, text = 0, "lost"                    # done on the server, but the answer is lost
            tr.res[rid] = (now + self.delay(), status, text)


class FakeTransport:
    """One browser's connection to the pretend database."""
    def __init__(self, db):
        self.db, self.res = db, {}

    def start(self, rid, method, url, body):
        self.db.send(self, rid, method, url, body)

    def take(self, rid):
        v = self.res.get(rid)
        if v is None or v[0] > self.db.now():
            return None
        del self.res[rid]
        return v[1], v[2]


# ==========================================
# 13. TESTS: A FAKE STUDENT  (--fake: the same rules as the screens, without the screens)
# ==========================================
class Bot:
    def __init__(self, make_net, clock, room_no, mon, mode, speed=1, observer=False, rec=None):
        self.make_net, self.clock, self.room_no, self.speed = make_net, clock, room_no, speed
        self.mon, self.mode, self.observer = mon, mode, observer
        self.net = make_net()
        self.me = new_id() + ("tch" if observer else mon[:3].lower())
        self.acc = random.uniform(*STUDENT_ACCURACY)
        self.get_up_at = random.randint(1, 4)     # how patient this student is when fainted
        self.rec = rec if rec is not None else {}
        self.faints = self.resets = 0
        self.gids = set()                          # every raid this student was in
        self.state = "out"                         # out / lobby / raid / done / gone (closed the tab)
        self.paused_until = 0
        self.result = None
        self.room = None

    def join_room(self):
        self.room = Room(self.net, self.clock, self.room_no, self.me, observer=self.observer)
        self.room.pick(self.mon)
        self.state, self.next_click = "lobby", 0

    def think(self):
        return random.uniform(*STUDENT_SECONDS) * 1000 / self.speed

    def enter(self, g):
        self.state, self.gid, self.g = "raid", g["id"], g
        self.gids.add(g["id"])
        self.fighter = Fighter(self.mon, g.get("mode"))
        self.killed, self.wipe_since = False, None
        self.room.send(self.gid, self.fighter)
        self.next_t = self.clock.now() + self.think()

    def finish(self, result):
        if result == "reset":                      # like the game: back to the topics, then join again
            self.resets += 1
            self.room.leave()
            self.join_room()
            return
        self.state, self.result, self.done_at = "done", result, self.clock.now()

    def step(self, can_start):
        now = self.clock.now()
        if self.state in ("out", "gone") or now < self.paused_until:
            return
        r = self.room
        r.update()
        if self.state == "done":
            if now - self.done_at > 6000:          # the ranking screen, then back to the topics
                r.leave()
                self.state = "gone"
            return
        if self.state == "lobby":
            g = r.game()
            if g is not None and r.my_pick():
                self.enter(g)
            elif can_start and r.is_leader() and now >= self.next_click:
                r.start(self.mode)                 # an impatient leader clicks again and again
                self.next_click = now + random.uniform(400, 2000) / self.speed
            return
        self.raid_step(now)

    def raid_step(self, now):
        r = self.room
        g = r.game_by_id(self.gid)
        if g is None and r.gone(self.gid):
            return self.finish("reset")
        g = self.g = g or self.g
        fresh = r.fresh()
        hp, full = boss_numbers(g, self.me, r.mine())
        left = time_left_ms(g, now)
        over = g.get("over")
        res = None
        if over in ("win", "lose"):
            res = over
        elif over in ("left", "dup"):
            self.rec.setdefault("closed_under_me", 0)
            self.rec["closed_under_me"] += 1
            return self.finish("reset")
        elif self.killed or (hp <= 0 and fresh):
            res = "win"
        elif left <= 0:
            res = "lose"
        if fresh and all_fainted(g, now, self.me, r.mine()):
            self.wipe_since = self.wipe_since if self.wipe_since is not None else now
        else:
            self.wipe_since = None
        if res is None and self.wipe_since is not None and now - self.wipe_since >= WIPE_MS / self.speed:
            res = "lose-wipe"
        if res:
            r.end(self.gid, "lose" if res == "lose-wipe" else res)
            return self.finish(res)
        if self.observer or now < self.next_t:
            return
        f = self.fighter
        if f.resting(now):
            return
        if f.can_get_up() and f.revive >= self.get_up_at:
            ev = f.get_up()
        elif not f.fainted and f.berries and f.hp < 90:
            ev = f.eat_berry()                     # low on HP: a Sitrus Berry
        else:
            ok = random.random() < self.acc
            was_fainted = f.fainted
            ev = f.answer(ok, hp, full, now)
            if f.fainted and not was_fainted:
                self.faints += 1
            if f.rest_until > now:
                f.rest_until = now + REST_MS / self.speed
            if any(kind == "boss_faint" for _, kind, _, _ in ev):
                self.killed = True
            ev = ev + [("Correct!" if ok else "Incorrect!",)] + ([] if ok else [("answer",)])
        r.send(self.gid, f)
        self.next_t = now + len(ev) * MSG_SECONDS * 1000 / self.speed + self.think()


def run(students, mode, speed, fake, net="school", teacher=False, leader_drops=False, verbose=True):
    """One raid with fake students.  Returns a dict of what happened."""
    random.seed()
    vt = [1.8e12]
    if fake:
        db = FakeDB(lambda: vt[0], net)
        make_net = lambda: Net("https://fake.firebaseio.com", FakeTransport(db), now=lambda: vt[0])
        speed = 1
    else:
        db = None
        make_net = lambda: Net(FIREBASE_URL, ThreadTransport())

    def new_clock():
        if fake:
            c = Clock(local=lambda: vt[0])
            c.offset = random.uniform(-2000, 2000)          # ClockSync is never perfect
            return c
        c = Clock()
        n = make_net()
        sync = ClockSync(n, c, "rtest" + new_id())
        while not sync.update():
            n.update()
            time.sleep(0.05)
        return c

    if not fake:
        n0 = make_net()
        n0.delete(f"{RAID_ROOT}/{raid_room_key(TEST_ROOM)}")
        time.sleep(1)
    rec = {}
    mons = pool()
    bots = []
    if teacher:
        bots.append(Bot(make_net, new_clock(), TEST_ROOM, OBSERVER, mode, speed, observer=True, rec=rec))
    for i in range(students):
        bots.append(Bot(make_net, new_clock(), TEST_ROOM, random.choice(mons), mode, speed, rec=rec))
    # students arrive over the first minute (the teacher, if any, first)
    arrive = [0 if (teacher and i == 0) else random.uniform(2000, 60000) / speed for i in range(len(bots))]
    arrive[0] = 0
    dropper = bots[0] if leader_drops else None

    def tick():
        if fake:
            vt[0] += TICK_MS
            db.tick()
        else:
            time.sleep(TICK_MS / 1000)
        for b in bots:
            b.net.update()

    t0 = bots[0].clock.local()
    limit = (RAID_MS + 240000) / speed
    gids, start_at, end_at, last_main = set(), None, None, None
    marks, next_mark = [], 0
    while True:
        tick()
        el = bots[0].clock.local() - t0
        for b, a in zip(bots, arrive):
            if b.state == "out" and el >= a:
                b.join_room()
            if b is dropper and b.state == "lobby" and el >= 20000 / speed:
                b.state = "gone"                     # closed the tab without pressing Back
            if fake and b.state in ("lobby", "raid") and b.paused_until < b.clock.now() \
                    and random.uniform(0, 100) < TAB_SWITCH["chance_per_min"] * TICK_MS / 60000:
                b.paused_until = b.clock.now() + random.uniform(*TAB_SWITCH["seconds"]) * 1000
            # the leader presses Start once most of the class is in (or after 90 s)
            here = sum(1 for x in bots if x.state in ("lobby", "raid"))
            b.step(can_start=here >= 0.8 * len(bots) or el >= 90000 / speed)
        for b in bots:
            if b.state == "raid":
                gids.add(b.gid)
        main = next((b.g for b in bots if b.state == "raid" and b.room.game_by_id(b.gid)), None)
        last_main = main or last_main
        if main is not None and start_at is None:
            start_at = el
        if main is not None:
            hp, full = boss_numbers(main)
            mins = (el - start_at) * speed / 60000
            if mins >= next_mark:
                marks.append((next_mark, hp, full))
                next_mark += 2
        if end_at is None and any(b.result for b in bots):
            end_at = el
        if start_at is not None and all(b.state in ("done", "gone", "out") for b in bots if b is not dropper):
            break
        if el > limit:
            break

    results = [b.result for b in bots if b.result]
    main_result = max(set(results), key=results.count) if results else None
    out = {
        "result": main_result,
        "minutes": None,
        "raids_started": len(db.raids_seen) if fake else len(gids),
        "raids_joined": len(gids),
        "resets": sum(b.resets for b in bots),
        "students_reset": sum(1 for b in bots if b.resets),
        "disagree": len(set(r.replace("-wipe", "") for r in results)) > 1,
        "faints": _mean(b.faints for b in bots if not b.observer) if students else 0,
        "closed_under_me": rec.get("closed_under_me", 0),
    }
    if end_at is not None and start_at is not None:
        out["minutes"] = (end_at - start_at) * speed / 60000
    if verbose:
        print(f"\n  {students} fake students, {mode_info(mode)['name']}, Wi-Fi: {net if fake else 'real'}"
              + (", teacher watching" if teacher else "") + (", leader closes the tab" if leader_drops else ""))
        for m, hp, full in marks:
            bar = "#" * round(30 * hp / full)
            print(f"    {m:4.0f} min  {bar:<30} {hp:>6} / {full}")
        res = out["result"]
        if res == "win":
            print(f"  Mewtwo fainted after about {out['minutes']:.1f} minutes.")
        elif res == "lose-wipe":
            print("  Everyone fainted.  The class loses.")
        elif res == "lose":
            print("  Time ran out.  The class loses.")
        else:
            print("  The raid never finished (check the internet connection).")
        print(f"  Raids started: {out['raids_started']}   (extra Starts are closed automatically; "
              f"students were in {out['raids_joined']} raid(s))")
        print(f"  Resets: {out['resets']}   Everyone saw the same result: {'no' if out['disagree'] else 'yes'}")
        print(f"  Faints per student: {out['faints']:.1f}")
        if last_main:
            print("  Top 10: " + ", ".join(name for name, _ in ranking(last_main)))
    for b in bots:
        if b.room is not None:
            b.room.leave()
    if not fake:
        tick()
        n = make_net()
        n.delete(f"{RAID_ROOT}/{raid_room_key(TEST_ROOM)}")
        for _ in range(30):
            n.update()
            time.sleep(0.1)
        print("  (Test room deleted.)")
    return out


# ==========================================
# 14. TESTS: FILE CHECK
# ==========================================
def check_files(folder):
    missing = []

    def need(path, what):
        if not os.path.exists(os.path.join(folder, path)):
            missing.append(f"{path}   ({what})")

    for name in roster() + [BOSS]:
        n = pokedex.info(name).get("folder")
        base = f"pokemon{n}/pokemon{n}"
        front = os.path.exists(os.path.join(folder, f"{base}_front (1).gif"))
        back = os.path.exists(os.path.join(folder, f"{base}_back (1).gif"))
        old = os.path.exists(os.path.join(folder, f"pokemon{n}/pokemon_{n} (1).gif"))
        if not (front or back or old):
            missing.append(f"{base}_front (1).gif   ({name}: no sprites at all)")
        elif name != BOSS and not back:
            missing.append(f"{base}_back (1).gif   ({name}: no back sprite, the front one is used)")
        elif name == BOSS and not front:
            missing.append(f"{base}_front (1).gif   ({name}: no front sprite, the back one is used)")
        need(f"{base}_faint.ogg", f"{name}'s faint sound")
    for f in RAID_MUSIC:
        need(f, "raid music")
    need(RAID_BACKGROUND, "raid background")
    need("caslon.ttf", "font")
    print(f"Pokemon students can pick ({len(pool())}): " + ", ".join(pool()))
    print(f"Teacher (watches): {OBSERVER}")
    if missing:
        print(f"\nMissing ({len(missing)}):")
        for m in missing:
            print("   " + m)
    else:
        print("\nAll raid files are there.")


def main_cli():
    import argparse              # tests only: pygbag's Python does not need it
    ap = argparse.ArgumentParser()
    ap.add_argument("--check-files", action="store_true")
    ap.add_argument("--make-pin")
    ap.add_argument("--dir", default=".")
    ap.add_argument("--students", type=int, default=25)
    ap.add_argument("--mode", default="medium", choices=MODE_ORDER)
    ap.add_argument("--speed", type=float, default=10)
    ap.add_argument("--fake", action="store_true")
    ap.add_argument("--net", default="school", choices=list(NETS))
    ap.add_argument("--teacher", action="store_true")
    ap.add_argument("--leader-drops", action="store_true")
    ap.add_argument("--runs", type=int, default=1)
    ap.add_argument("--screens", action="store_true")
    ap.add_argument("--pin", default="1202")
    ap.add_argument("--topic", type=int, default=SIM_TOPIC)
    a = ap.parse_args()
    if a.check_files:
        check_files(a.dir)
        sys.exit()
    if a.make_pin:
        if not a.make_pin.isdigit() or not 4 <= len(a.make_pin) <= 8:
            sys.exit("The PIN must be 4 to 8 digits.")
        print("Paste this line into online.py (replacing the old TEACHER_PIN_HASH line):")
        print(f'TEACHER_PIN_HASH = "{pin_hash(a.make_pin)}"')
        sys.exit()
    if a.screens:
        globals()["SIM_TOPIC"] = a.topic
        outs = [run_screens(a.students, a.mode, a.net, a.teacher, a.leader_drops, verbose=True, pin=a.pin)
                for _ in range(a.runs)]
        if a.runs > 1:
            print(f"\n{a.runs} runs: resets {sum(o['resets'] for o in outs)}, raids created (most) "
                  f"{max(o['raids_started'] for o in outs)}, crashes {sum(o['crashes'] for o in outs)}, "
                  f"results {[o['result'] for o in outs]}")
        return
    outs = [run(a.students, a.mode, a.speed, a.fake, a.net, a.teacher, a.leader_drops, verbose=(a.runs == 1))
            for _ in range(a.runs)]
    if a.runs > 1:
        won = [o["minutes"] for o in outs if o["result"] == "win" and o["minutes"] is not None]
        print(f"{a.students} students, {a.mode}, Wi-Fi {a.net}: won {len(won)}/{a.runs}"
              + (f", average {_mean(won):.1f} min" if won else "")
              + f" | raids started (most) {max(o['raids_started'] for o in outs)}"
              + f", students ever in 2+ raids: {sum(o['raids_joined'] > 1 for o in outs)} runs"
              + f", resets total {sum(o['resets'] for o in outs)}"
              + f", runs where screens disagreed {sum(o['disagree'] for o in outs)}")


# ==========================================
# 15. TESTS: THE REAL RAID SCREENS, PLAYED BY FAKE STUDENTS  (--screens)
#   battles.py's real screens and main.py's real questions, for the whole class at once, on the pretend
#   database.  A stand-in for pygame draws nothing but remembers the text on each screen; the fake
#   students read it and click (topic, PIN, Pokemon, Start, answers, graphs, berries...), switch tabs,
#   and with --leader-drops the first one in the room closes the tab before Start.
# ==========================================
SIM_FPS_MS = 100                     # one screen frame every 0.1 s (pretend time)
SIM_TOPIC = 8                        # Unit 4 Review (--topic)


def _fake_pygame(vclock, current):
    """A stand-in for pygame: same names, draws nothing, remembers the text on each screen."""
    import types as _t
    pg = _t.ModuleType("pygame")

    class error(RuntimeError):
        pass

    def _pair(v):
        return (v[0], v[1])

    class Rect:
        def __init__(self, *a):
            if len(a) == 1:
                a = (a[0].x, a[0].y, a[0].w, a[0].h) if isinstance(a[0], Rect) else tuple(a[0])
            if len(a) == 2:
                a = (a[0][0], a[0][1], a[1][0], a[1][1])
            self.x, self.y, self.w, self.h = (int(v) for v in a)

        width = property(lambda s: s.w, lambda s, v: setattr(s, "w", int(v)))
        height = property(lambda s: s.h, lambda s, v: setattr(s, "h", int(v)))
        left = property(lambda s: s.x, lambda s, v: setattr(s, "x", int(v)))
        top = property(lambda s: s.y, lambda s, v: setattr(s, "y", int(v)))
        right = property(lambda s: s.x + s.w, lambda s, v: setattr(s, "x", int(v) - s.w))
        bottom = property(lambda s: s.y + s.h, lambda s, v: setattr(s, "y", int(v) - s.h))
        centerx = property(lambda s: s.x + s.w // 2, lambda s, v: setattr(s, "x", int(v) - s.w // 2))
        centery = property(lambda s: s.y + s.h // 2, lambda s, v: setattr(s, "y", int(v) - s.h // 2))
        size = property(lambda s: (s.w, s.h))

        def _pt(name, fx, fy):
            def get(s):
                return (getattr(s, fx), getattr(s, fy))

            def put(s, v):
                setattr(s, fx, v[0])
                setattr(s, fy, v[1])
            return property(get, put)
        center = _pt("center", "centerx", "centery")
        topleft = _pt("topleft", "left", "top")
        topright = _pt("topright", "right", "top")
        bottomleft = _pt("bottomleft", "left", "bottom")
        bottomright = _pt("bottomright", "right", "bottom")
        midleft = _pt("midleft", "left", "centery")
        midright = _pt("midright", "right", "centery")
        midtop = _pt("midtop", "centerx", "top")
        midbottom = _pt("midbottom", "centerx", "bottom")

        def collidepoint(self, *p):
            x, y = _pair(p[0]) if len(p) == 1 else p
            return self.x <= x < self.x + self.w and self.y <= y < self.y + self.h

        def copy(self):
            return Rect(self.x, self.y, self.w, self.h)

        def move(self, dx, dy):
            return Rect(self.x + dx, self.y + dy, self.w, self.h)

        def inflate(self, dx, dy):
            return Rect(self.x - dx // 2, self.y - dy // 2, self.w + dx, self.h + dy)

        def __iter__(self):
            return iter((self.x, self.y, self.w, self.h))

        def __getitem__(self, i):
            return (self.x, self.y, self.w, self.h)[i]

        def __len__(self):
            return 4

    class Surface:
        def __init__(self, size, flags=0, *a):
            self.w, self.h = max(1, int(size[0])), max(1, int(size[1]))
            self.texts = []

        def get_width(self):
            return self.w

        def get_height(self):
            return self.h

        def get_size(self):
            return (self.w, self.h)

        def get_rect(self, **kw):
            r = Rect(0, 0, self.w, self.h)
            for k, v in kw.items():
                setattr(r, k, v)
            return r

        def fill(self, color, rect=None, special_flags=0):
            if rect is None and not special_flags:
                self.texts = []

        def blit(self, src, dest, area=None, special_flags=0):
            x, y = (dest.x, dest.y) if isinstance(dest, Rect) else (int(dest[0]), int(dest[1]))
            if src.texts and len(self.texts) < 400:
                self.texts.extend((t, Rect(r.x + x, r.y + y, r.w, r.h)) for t, r in src.texts)

        def get_bounding_rect(self):
            return Rect(0, 0, self.w, self.h)

        def subsurface(self, r):
            return Surface((Rect(r).w, Rect(r).h))

        def copy(self):
            s = Surface((self.w, self.h))
            s.texts = list(self.texts)
            return s

        def convert_alpha(self):
            return self

        def convert(self):
            return self

        def set_clip(self, *a):
            pass

        def set_alpha(self, *a):
            pass

    class Font:
        def __init__(self, path=None, size=20):
            self.s = max(1, int(size))

        def size(self, text):
            return (max(1, int(len(str(text)) * self.s * 0.5)), int(self.s * 1.2))

        def render(self, text, aa=True, color=(0, 0, 0), bg=None):
            surf = Surface(self.size(text))
            if str(text).strip():
                surf.texts = [(str(text), Rect(0, 0, surf.w, surf.h))]
            return surf

        def get_height(self):
            return int(self.s * 1.2)

        def get_ascent(self):
            return self.s

        def metrics(self, text):
            return [(0, self.s // 2, 0, self.s, self.s // 2) for _ in str(text)]

    def _no_file(*a, **k):
        raise FileNotFoundError("no files in the screen test")

    class Clock:
        def tick(self, *a):
            return SIM_FPS_MS

    def _update(*a):
        st = current.get(None)
        if st is not None:
            st.frame = list(st.screen.texts)

    def _get_events(*a, **k):
        st = current.get(None)
        if st is None:
            return []
        ev, st.events = st.events, []
        return ev

    noop = lambda *a, **k: None
    pg.error, pg.Rect, pg.Surface = error, Rect, Surface
    pg.QUIT, pg.KEYDOWN, pg.MOUSEBUTTONDOWN, pg.USEREVENT = 256, 768, 1025, 32866
    pg.K_RETURN, pg.K_KP_ENTER, pg.K_BACKSPACE, pg.K_ESCAPE = 13, 1073741912, 8, 27
    pg.SRCALPHA, pg.BLEND_RGBA_MULT = 65536, 8
    pg.init = pg.quit = noop
    pg.font = _t.SimpleNamespace(Font=Font, init=noop, SysFont=lambda *a, **k: Font(None, a[1] if len(a) > 1 else 20))
    pg.draw = _t.SimpleNamespace(rect=noop, line=noop, lines=noop, circle=noop, polygon=noop, ellipse=noop,
                                 arc=noop, aaline=noop)
    pg.image = _t.SimpleNamespace(load=_no_file, tobytes=lambda *a: b"", tostring=lambda *a: b"")
    pg.transform = _t.SimpleNamespace(scale=lambda s, size: Surface(size),
                                      rotate=lambda s, a: Surface((s.h, s.w)),
                                      smoothscale=lambda s, size: Surface(size))
    pg.mixer = _t.SimpleNamespace(pre_init=noop, init=noop, Sound=_no_file,
                                  music=_t.SimpleNamespace(load=_no_file, play=noop, stop=noop, set_volume=noop,
                                                           set_endevent=noop, get_busy=lambda: False))
    pg.time = _t.SimpleNamespace(get_ticks=lambda: int(vclock()), Clock=Clock)
    pg.display = _t.SimpleNamespace(set_mode=lambda size, *a: Surface(size), update=_update, flip=_update,
                                    set_caption=noop)
    pg.event = _t.SimpleNamespace(get=_get_events, Event=lambda t, **k: _t.SimpleNamespace(type=t, **k))
    return pg


class _SimStudent:
    """One fake student (or Mr. Chung) playing the real screens."""
    def __init__(self, i, mon, teacher, pg):
        self.i, self.mon, self.teacher = i, mon, teacher
        self.screen = pg.Surface((1080, 950))
        self.frame, self.events = [], []
        self.acc = random.uniform(*STUDENT_ACCURACY)
        self.get_up_at = random.randint(1, 4)
        self.paused_until, self.closed, self.task, self.crash = 0, False, None, None
        self.where, self.came_from = "", ""
        self.next_act, self.q, self.q_seen, self.answer_at = 0, None, None, 0
        self.pin_left = None
        self.resets = self.raids = self.starts = 0
        self.result, self.done = None, False
        self.raid_frames = self.slow_frames = self.graph_seen = 0

    # ----- reading the screen -----
    def has(self, piece):
        return any(piece in t for t, _ in self.frame)

    def find(self, text):
        return next((r.center for t, r in self.frame if t == text), None)

    def screen_name(self):
        if self.has("Class Raid: pick a topic"):
            return "review"
        if self.has("Enter the PIN"):
            return "pin"
        if self.has("Top 10 raiders"):
            return "end"
        if self.has("Time left"):
            return "raid"
        if any(t.startswith("Online Class Raid  -  ") for t, _ in self.frame):
            return "lobby"
        if self.has("Click anywhere to go back."):
            return "message"
        return "?"

    def click(self, pg, pos):
        self.events.append(pg.event.Event(pg.MOUSEBUTTONDOWN, pos=(int(pos[0]), int(pos[1])), button=1))


def _sim_brain(st, pg, now, expected, t_first):
    """What a fake student does this frame, from what is on their screen."""
    if st.task is None or st.closed or st.done or now < st.paused_until or now < st.next_act:
        return
    where = st.screen_name()
    if where != st.where:
        st.came_from, st.where = st.where, where
        if where == "review" and st.came_from == "raid":
            st.resets += 1                             # thrown out of a raid back to the topics
        if where == "raid":
            st.raids += 1
    act = lambda ms: setattr(st, "next_act", now + random.uniform(*ms))
    if where == "review":
        if st.came_from == "end":
            st.done = True                             # played one raid: finished
            return
        if st.teacher and not st.has("Teacher: ON"):
            p = st.find("Teacher")
            if p:
                st.click(pg, p)
        else:
            p = st.find(_SIM_TITLE)
            if p:
                st.click(pg, p)
        act((600, 1500))
    elif where == "pin":
        if st.pin_left is None:
            st.pin_left = list(_SIM_PIN) + ["OK"]
        if st.pin_left:
            p = st.find(st.pin_left[0])
            if p:
                st.click(pg, p)
                st.pin_left.pop(0)
        act((200, 500))
    elif where == "lobby":
        if st.has("Click a Pokemon to pick it."):
            p = st.find(st.mon)
            if p:
                st.click(pg, p)
            act((500, 2000))
        elif st.has("Start the raid!") and not getattr(st, "mode_set", False):
            p = st.find(_SIM_MODE)
            if p:
                st.click(pg, p)                        # choose the difficulty first
                st.mode_set = True
            act((400, 1200))
        elif st.has("Start the raid!"):
            m = next((t for t, _ in st.frame if "in this room)" in t or t.endswith(" in this room")), "")
            digits = "".join(ch if ch.isdigit() else " " for ch in m.split("in this room")[0][-6:]).split()
            here = int(digits[-1]) if digits else 0
            if here >= 0.8 * expected or now - t_first > 90000:
                p = st.find("Start the raid!")
                if p:
                    st.click(pg, p)                    # an impatient leader clicks again and again
                    st.starts += 1
            act((400, 2000))
    elif where == "raid":
        st.raid_frames += 1
        if st.has("Slow connection"):
            st.slow_frames += 1
        if st.has("Click anywhere to see the ranking."):
            st.click(pg, (540, 400))
            act((800, 2500))
            return
        if st.teacher:
            return
        q = st.q
        btn = [(225, 825), (540, 825), (855, 825), (225, 895), (540, 895)]
        if st.has("go back to the answers"):           # the graph / table screen is open: close it
            st.graph_seen += 1
            st.click(pg, (540, 500))
            act((400, 1200))
            return
        clean = sys.modules["main_tool"].clean_text
        showing = q is not None and st.has(clean(q.text).split("\u00b2")[0].split("\n")[0][:12])
        if showing and q.graph is not None and st.q_seen is q and getattr(st, "looked", None) is not q \
                and random.random() < 0.5:
            st.looked = q                               # opens the graph / table once in a while
            st.click(pg, (920, 765))
            act((3000, 9000))
            return
        my_hp = next((int(t.split()[1]) for t, _ in st.frame
                      if t.startswith("HP: ") and t.endswith(f"/ {RAID_PLAYER_HP}")), None)
        berry = next((t for t, _ in st.frame if t.startswith("Sitrus Berry x") and not t.endswith("x0")), None)
        if showing and berry and my_hp is not None and my_hp < 90:
            st.click(pg, st.find(berry))                # low on HP: eat a Sitrus Berry
            st.berries_used = getattr(st, "berries_used", 0) + 1
            act((500, 1500))
            return
        p = st.find(next((t for t, _ in st.frame if t.startswith("Get up now")), ""))
        if p:
            pct = int("".join(ch for ch in next(t for t, _ in st.frame if t.startswith("Get up now")) if ch.isdigit()) or 0)
            if pct >= 20 * st.get_up_at:
                st.click(pg, p)
                act((500, 1500))
                return
        if showing:
            if st.q_seen is not q:
                st.q_seen, st.answer_at = q, now + random.uniform(*STUDENT_SECONDS) * 1000
            elif now >= st.answer_at:
                right = q.options.index(q.correct)
                pick = right if random.random() < st.acc else random.choice([i for i in range(5) if i != right])
                st.click(pg, btn[pick])
                st.q_seen = None
                act((300, 800))
        elif random.random() < 0.02:
            st.click(pg, (300, 765))                   # sometimes clicks to skip a message
    elif where == "end":
        if st.result is None:
            st.result = "win" if st.has(" was defeated!") else "lose"
        st.click(pg, (540, 500))
        act((2500, 4000))
    elif where == "message":
        st.click(pg, (540, 500))
        act((800, 1500))


_SIM_PIN = None
_SIM_MODE = "Medium"
_SIM_TITLE = ""
_SIM = {}


def run_screens(students, mode, net, teacher, leader_drops, verbose=True, pin="1202"):
    """The real Class Raid screens, played by fake students on the pretend database."""
    import asyncio
    import contextvars
    import traceback
    global _SIM_PIN, _SIM_MODE
    _SIM_MODE = mode_info(mode)["name"]
    if not _SIM:                                       # set up once per Python run (later runs reuse it)
        if "pygame" in sys.modules:
            sys.exit("Run --screens in a fresh Python (it replaces pygame with a stand-in).")
        _SIM["vt"] = [1.8e12]
        _SIM["current"] = contextvars.ContextVar("sim_student")
        _SIM["pg"] = _fake_pygame(lambda: _SIM["vt"][0], _SIM["current"])
        sys.modules["pygame"] = _SIM["pg"]
        import battles
        import main as game                            # the real Precalc questions, graphs and tables
        _SIM["frame"], _SIM["game"] = battles.frame, game
    import battles
    game = _SIM["game"]
    vt, current, pg = _SIM["vt"], _SIM["current"], _SIM["pg"]
    vt[0] += 3600000                                   # a new pretend hour for each run
    vclock = lambda: vt[0]
    db = FakeDB(vclock, net)
    Net.__init__.__defaults__ = (vclock,)
    Clock.__init__.__defaults__ = (vclock,)
    globals()["make_transport"] = lambda: FakeTransport(db)
    global _SIM_TITLE
    game.OPEN_LEVELS.add(SIM_TOPIC)                    # (the test opens its topic even before its date)
    _SIM_TITLE = game.topic_title(SIM_TOPIC)
    api = game.make_api()

    def next_question(level):
        q = game.next_question(level)
        current.get().q = q                          # the fake student knows which answer is right
        return q
    api.next_question = next_question
    real_frame = _SIM["frame"]

    async def frame(clock, fps):
        await real_frame(clock, fps)
        st = current.get()
        while st.closed or vt[0] < st.paused_until:     # a hidden or closed tab: the game stops
            await asyncio.sleep(0)
    battles.frame = frame
    _SIM_PIN = str(pin)                                 # the PIN typed on the keypad (--pin, if you changed it)
    if not check_pin(_SIM_PIN):
        _SIM_PIN = None

    pool_ = pool()
    sts = []
    if teacher:
        if _SIM_PIN is None:
            print("  (Wrong PIN for the screen test: add --pin with your PIN. No teacher this time.)")
            teacher = False
        else:
            sts.append(_SimStudent(0, OBSERVER, True, pg))
    for i in range(students):
        sts.append(_SimStudent(len(sts), random.choice(pool_), False, pg))
    arrive = [0] + [random.uniform(2000, 60000) for _ in sts[1:]]
    sounds = {k: None for k in ("click", "correct", "heal", "hit", "firepunch", "thunderbolt", "hydropump",
                                "leaftornado")}
    sounds["music_pool"] = []
    dropper = sts[0] if leader_drops else None        # the first one in the room (Mr. Chung, if he's there)

    async def play(st):
        try:
            await battles.raid_mode(st.screen, pg.time.Clock(), 10, dict(sounds), {}, api)
        except Exception:
            st.crash = traceback.format_exc()

    async def main():
        t0 = vt[0]
        limit = t0 + RAID_MS + 6 * 60000
        while vt[0] < limit:
            vt[0] += SIM_FPS_MS
            db.tick()
            now = vt[0]
            for st, a in zip(sts, arrive):
                if st.task is None and now - t0 >= a:
                    tok = current.set(st)
                    st.task = asyncio.ensure_future(play(st))
                    current.reset(tok)
                if st is dropper and not st.closed and st.where == "lobby" and now - t0 > 25000:
                    st.closed = True                   # closed the tab without pressing Back
                if (st.task is not None and not st.done and now >= st.paused_until
                        and random.uniform(0, 100) < TAB_SWITCH["chance_per_min"] * SIM_FPS_MS / 60000):
                    st.paused_until = now + random.uniform(*TAB_SWITCH["seconds"]) * 1000
                _sim_brain(st, pg, now, len(sts), t0)
            await asyncio.sleep(0)
            if any(st.crash for st in sts):
                break
            if all(st.done or st.closed for st in sts if st.task is not None) and all(st.task for st in sts):
                break
        for st in sts:
            if st.task is not None and not st.task.done():
                st.task.cancel()
        await asyncio.sleep(0)
        return (vt[0] - t0) / 60000

    minutes = asyncio.run(main())
    crashes = [st.crash for st in sts if st.crash]
    played = [st for st in sts if not st.teacher]
    res = [st.result for st in played if st.result]
    out = {"raids_started": len(db.raids_seen), "resets": sum(st.resets for st in sts),
           "students_reset": sum(1 for st in sts if st.resets), "crashes": len(crashes),
           "result": max(set(res), key=res.count) if res else None, "agree": len(set(res)) <= 1,
           "finished": sum(1 for st in played if st.result), "players": sum(1 for st in played if not st.closed),
           "slow": sum(st.slow_frames for st in sts) / max(1, sum(st.raid_frames for st in sts)),
           "start_clicks": sum(st.starts for st in sts), "minutes": minutes,
           "graphs": sum(st.graph_seen for st in sts),
           "berries": sum(getattr(st, "berries_used", 0) for st in sts)}
    if verbose:
        print(f"\n  REAL raid screens, {_SIM_TITLE}: {students} fake students, {mode_info(mode)['name']}, "
              f"Wi-Fi: {net}" + (", Mr. Chung watching (PIN typed on the keypad)" if teacher else "")
              + (", the first one in the room closes the tab in the lobby" if leader_drops else ""))
        print(f"  Result: {out['result'] or 'no result'}   (students who saw the ranking: "
              f"{out['finished']} of {out['players']}; everyone saw the same result: {'yes' if out['agree'] else 'NO'})")
        print(f"  Start clicked {out['start_clicks']} times -> raids created: {out['raids_started']}")
        print(f"  Resets (thrown out of a raid): {out['resets']}")
        print(f"  Graph / table screens opened (and closed again) by students: {out['graphs']}")
        print(f"  Sitrus Berries eaten: {out['berries']}")
        print(f"  'Slow connection: reconnecting...' shown {100 * out['slow']:.1f}% of the time in the raid")
        print(f"  Simulated time: {minutes:.1f} minutes")
        for c in crashes[:1]:
            print("  A SCREEN CRASHED:\n" + c)
    return out


if __name__ == "__main__":
    import online          # run inside the "online" module itself (the same one the screens use)
    online.main_cli()
